export type SubtitleFormat = 'srt' | 'ass';

export type AIModelId =
  | 'gemini-3.8-flash'
  | 'gemini-3.7-flash'
  | 'gemini-3.1-pro-preview'
  | 'gemini-2.5-pro'
  | 'gpt-4o'
  | 'claude-3.5-sonnet'
  | 'llama-3.1-405b';

export type AIModelProfile =
  | AIModelId
  | 'deep_context'
  | 'lightning_fast'
  | 'creative_colloquial';

export interface AIModelOption {
  id: AIModelId;
  name: string;
  badge: string;
  badgeColor: string;
  burmeseSubtitle: string;
  iconTag: string;
}

export const PREMIUM_AI_MODELS: AIModelOption[] = [
  {
    id: 'gemini-3.8-flash',
    name: 'Gemini 3.8 Flash',
    badge: 'Recommended',
    badgeColor: 'text-[#3fb950] bg-[#2ea043]/20 border-[#2ea043]/40',
    burmeseSubtitle: 'အမြန်နှုန်း အထူးကောင်းမွန်ပြီး အခြေအနေနှင့် လိုက်လျောညီထွေ ဘာသာပြန်ပေးနိုင်ခြင်း',
    iconTag: '⚡',
  },
  {
    id: 'gemini-3.7-flash',
    name: 'Gemini 3.7 Flash',
    badge: 'Reasoning',
    badgeColor: 'text-indigo-300 bg-indigo-500/20 border-indigo-500/40',
    burmeseSubtitle: 'စာတန်းထိုး အထားအသိုနှင့် ရှုပ်ထွေးသော စာကြောင်းများကို တိကျစွာ ခွဲခြမ်းစိတ်ဖြာနိုင်ခြင်း',
    iconTag: '🧠',
  },
  {
    id: 'gemini-3.1-pro-preview',
    name: 'Gemini 3.1 Pro Preview',
    badge: 'Deep Nuance',
    badgeColor: 'text-amber-300 bg-amber-500/20 border-amber-500/40',
    burmeseSubtitle: 'ယဉ်ကျေးမှုဆိုင်ရာ အသုံးအနှုန်းများ၊ အခေါ်အဝေါ်နှင့် အနက်အဓိပ္ပာယ်ကို အနက်ရှိုင်းဆုံး စဉ်းစားပေးခြင်း',
    iconTag: '✨',
  },
  {
    id: 'gemini-2.5-pro',
    name: 'Gemini 2.5 Pro',
    badge: 'Long-Context',
    badgeColor: 'text-cyan-300 bg-cyan-500/20 border-cyan-500/40',
    burmeseSubtitle: 'စကားပြောအရှည်ကြီးများနှင့် ရေရှည်အဆက်အစပ်ကို အတည်ငြိမ်ဆုံး ဘာသာပြန်ပေးခြင်း',
    iconTag: '📦',
  },
  {
    id: 'gpt-4o',
    name: 'GPT-4o',
    badge: 'Flagship Speed',
    badgeColor: 'text-emerald-300 bg-emerald-500/20 border-emerald-500/40',
    burmeseSubtitle: 'အလွန်လျင်မြန်ပြီး တိကျမှုမြင့်မားသော Flagship စကားပြန်စနစ်',
    iconTag: '🚀',
  },
  {
    id: 'claude-3.5-sonnet',
    name: 'Claude 3.5 Sonnet',
    badge: 'Dialogue Flow',
    badgeColor: 'text-orange-300 bg-orange-500/20 border-orange-500/40',
    burmeseSubtitle: 'လူအစစ်ပြောသကဲ့သို့ အလွန်ချောမွေ့သဘာဝကျသော ရုပ်ရှင်စကားပြောဟန်',
    iconTag: '🎭',
  },
  {
    id: 'llama-3.1-405b',
    name: 'Llama 3.1 405B',
    badge: 'Linguistic',
    badgeColor: 'text-purple-300 bg-purple-500/20 border-purple-500/40',
    burmeseSubtitle: 'ဘာသာစကားဆိုင်ရာ အနက်ဖော်ပြချက် အထူးကြွယ်ဝသော Model ကြီး',
    iconTag: '🦙',
  },
];

export type SourceLanguage =
  | 'auto_detect'
  | 'Japanese'
  | 'Korean'
  | 'English'
  | 'Chinese'
  | 'Thai'
  | 'Other';

export interface SubtitleBlock {
  id: number;
  startTime: string; // "00:01:23,450" or "0:01:23.45"
  endTime: string;   // "00:01:26,800" or "0:01:26.78"
  startMs: number;
  endMs: number;
  sourceText: string;
  burmeseText: string;
  notes?: string;
  issues?: ValidationIssue[];
  status?: 'pending' | 'translating' | 'translated' | 'edited' | 'error';
  // Advanced features
  isTwoSpeaker?: boolean;
  speaker1?: string;
  speaker2?: string;
  isTooLong?: boolean;
  charCount?: number;
  readingCps?: number; // Characters per second
  // ASS (Advanced SubStation Alpha) metadata
  assRawLine?: string;
  assLayer?: string;
  assStyle?: string;
  assActor?: string;
  assMarginL?: string;
  assMarginR?: string;
  assMarginV?: string;
  assEffect?: string;
  assOverrideTags?: string; // e.g., "{\pos(192,250)\fs28}"
  // UI display control
  isRevealed?: boolean;
}

export interface ValidationIssue {
  type:
    | 'forbidden_punctuation'
    | 'literary_particle'
    | 'consecutive_ta'
    | 'sync_mismatch'
    | 'untranslated'
    | 'ass_tag_corrupted'
    | 'unnecessary_filler'
    | 'parentheses_detected'
    | 'brackets_detected'
    | 'line_too_long';
  message: string;
  severity: 'error' | 'warning';
  charOrWord?: string;
  suggestion?: string;
}

export type CharacterNamePolicy = 'keep_english' | 'burmese_transliteration';

export type PresetKey =
  | 'action_srt'
  | 'drama_srt'
  | 'comedy_srt'
  | 'romance_srt'
  | 'horror_thriller_srt'
  | 'crime_mystery_srt'
  | 'historical_period_srt'
  | 'kdrama_srt'
  | 'c_drama_srt'
  | 'anime_srt'
  | 'anime_ass'
  | 'animation_srt'
  | 'adult_srt'
  | 'supernatural_srt'
  | 'variety_show_srt'
  | 'reality_show_srt'
  | 'singing_competition_srt'
  | 'talent_show_srt'
  | 'action'
  | 'kdrama'
  | 'romance'
  | 'ambiguous';

export type GenreType =
  | 'Dynamic (Auto-Detect)'
  | 'C Drama'
  | 'Kdrama'
  | 'Drama'
  | 'Action'
  | 'Comedy'
  | 'Romance'
  | 'Horror'
  | 'Thriller'
  | 'Crime'
  | 'Historical'
  | 'Anime'
  | 'Animation'
  | 'Adult'
  | 'Supernatural'
  | 'Variety Show'
  | 'Reality Show'
  | 'Singing Competition'
  | 'Talent Show';

export type PronounTone =
  | 'auto_contextual'  // Auto / Contextual (Default)
  | 'ငါ/မင်း'          // Casual / Shonen
  | 'ကျုပ်/ခင်ဗျား'     // Formal / Polite
  | 'ကိုယ်/နင်'        // Romantic / Close
  | 'ကျွန်တော်/ခင်ဗျား' // Polite Male alias
  | 'ကိုယ်/မင်း'        // Romantic alias
  | 'custom';

export interface GlossaryEntry {
  id: string;
  source: string;
  burmese: string;
  note?: string;
}

export interface DetectedAmbiguity {
  blockId: number;
  sourcePhrase: string;
  query: string;
  options: string[];
  resolvedChoice?: string;
}

export interface ProjectSettings {
  modelProfile: AIModelProfile;
  selectedModel: AIModelId;
  sourceLanguage: SourceLanguage;
  subtitleFormat: SubtitleFormat;
  characterPolicy: CharacterNamePolicy;
  genre: GenreType;
  pronouns: PronounTone;
  formality: 'casual' | 'polite' | 'intimate' | 'gritty';
  autoSplitLongLines: boolean;
  twoSpeakerSeparation: boolean;
  filterFillerSounds: boolean;
  maxCharsPerLine: number;
  customGlossary: GlossaryEntry[];
  customRules: string[];
  additionalNotes: string;
  assHeaders?: string;
}
