import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Upload, Film, Eye, Type, Volume2 } from 'lucide-react';
import { SubtitleBlock } from '../types/subtitle';
import { msToTimecode } from '../utils/srtParser';

interface SubtitlePlayerPreviewProps {
  blocks: SubtitleBlock[];
  currentTimeMs: number;
  hasCompletedTranslation?: boolean;
  onTimeUpdate: (update: number | ((prev: number) => number)) => void;
}

export const SubtitlePlayerPreview: React.FC<SubtitlePlayerPreviewProps> = ({
  blocks,
  currentTimeMs,
  hasCompletedTranslation = false,
  onTimeUpdate,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [subtitleColor, setSubtitleColor] = useState<'yellow' | 'white'>('yellow');
  const [fontSize, setFontSize] = useState<number>(20);
  const [customVideoUrl, setCustomVideoUrl] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const timerRef = useRef<number | null>(null);

  // Compute total duration from last block or video
  const maxBlockMs = blocks.length > 0 ? Math.max(...blocks.map((b) => b.endMs)) + 2000 : 30000;
  const totalDurationMs = customVideoUrl && videoRef.current?.duration
    ? Math.round(videoRef.current.duration * 1000)
    : maxBlockMs;

  // Find active subtitle block at currentTimeMs
  const activeBlock = blocks.find(
    (b) => currentTimeMs >= b.startMs && currentTimeMs <= b.endMs
  );

  // Simulation playback loop if no video element is loaded
  useEffect(() => {
    if (isPlaying && !customVideoUrl) {
      const interval = 50; // update every 50ms
      timerRef.current = window.setInterval(() => {
        onTimeUpdate(prevTime => {
          const next = prevTime + interval * playbackRate;
          if (next >= totalDurationMs) {
            setIsPlaying(false);
            return 0;
          }
          return next;
        });
      }, interval);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, customVideoUrl, playbackRate, totalDurationMs]);

  // Video element sync
  const handleVideoTimeUpdate = () => {
    if (videoRef.current) {
      onTimeUpdate(Math.round(videoRef.current.currentTime * 1000));
    }
  };

  const togglePlay = () => {
    if (customVideoUrl && videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newMs = parseInt(e.target.value, 10);
    onTimeUpdate(newMs);
    if (videoRef.current && customVideoUrl) {
      videoRef.current.currentTime = newMs / 1000;
    }
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setCustomVideoUrl(url);
      setIsPlaying(false);
    }
  };

  const handleReset = () => {
    onTimeUpdate(0);
    setIsPlaying(false);
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.pause();
    }
  };

  return (
    <div className="bg-[#161b22] border border-[#30363d] rounded-2xl overflow-hidden shadow-2xl flex flex-col">
      {/* Visual Canvas / Video Screen */}
      <div className="relative aspect-video w-full bg-black flex items-center justify-center overflow-hidden group select-none">
        {customVideoUrl ? (
          <video
            ref={videoRef}
            src={customVideoUrl}
            onTimeUpdate={handleVideoTimeUpdate}
            onEnded={() => setIsPlaying(false)}
            className="w-full h-full object-contain"
          />
        ) : (
          <div className="relative w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#0e1117] via-[#161b22] to-emerald-950/30 p-6 text-center">
            {/* Ambient cinema visual backdrop */}
            <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#2ea043_1px,transparent_1px)] [background-size:16px_16px]"></div>
            
            <div className="relative z-10 flex flex-col items-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-[#21262d] border border-[#30363d] flex items-center justify-center shadow-inner">
                <Film className="w-6 h-6 text-[#3fb950] opacity-90" />
              </div>
              <p className="text-xs text-[#e6edf3] font-mono tracking-wider font-semibold">
                CINEMA PREVIEW MONITOR
              </p>
              <p className="text-[11px] text-[#7d8590] max-w-xs">
                Real-time synchronized subtitle render monitor with Burmese typography styling.
              </p>
            </div>
          </div>
        )}

        {/* Subtitle Rendering Overlay */}
        <div className="absolute inset-x-0 bottom-6 px-6 text-center pointer-events-none z-20">
          {activeBlock ? (
            <div className="inline-block max-w-3xl">
              <div
                className={`burmese-text cinema-subtitle font-bold px-4 py-1.5 rounded-lg transition-all ${
                  subtitleColor === 'yellow'
                    ? 'text-amber-300 bg-black/75 shadow-lg'
                    : 'text-white bg-black/75 shadow-lg'
                }`}
                style={{ fontSize: `${fontSize}px` }}
              >
                {hasCompletedTranslation && activeBlock.burmeseText ? (
                  activeBlock.burmeseText
                ) : (
                  <div className="space-y-0.5">
                    <span className="text-slate-200 text-sm font-normal">
                      {activeBlock.sourceText}
                    </span>
                    <span className="block text-[11px] text-amber-300 font-medium">
                      🔒 ဘာသာပြန်ရန် စောင့်ဆိုင်းနေပါသည်... (Hidden Until Translated)
                    </span>
                  </div>
                )}
              </div>
              {hasCompletedTranslation && activeBlock.burmeseText && (
                <div className="text-[11px] text-slate-400 mt-1 opacity-70">
                  {activeBlock.sourceText}
                </div>
              )}
            </div>
          ) : (
            <div className="text-[11px] text-[#7d8590] italic">
              (No dialogue at {msToTimecode(currentTimeMs)})
            </div>
          )}
        </div>

        {/* Top bar info inside screen */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-[11px] font-mono text-slate-300 bg-[#0e1117]/85 px-3 py-1 rounded-lg border border-[#30363d] backdrop-blur-sm pointer-events-none z-10">
          <span>{msToTimecode(currentTimeMs)}</span>
          <span className="text-[#3fb950] font-semibold">
            {activeBlock ? `SUBTITLE #${activeBlock.id}` : 'STANDBY'}
          </span>
          <span>{msToTimecode(totalDurationMs)}</span>
        </div>
      </div>

      {/* Media Controls Toolbar */}
      <div className="p-4 bg-[#0e1117] border-t border-[#30363d] space-y-3 text-xs">
        {/* Progress Scrubber */}
        <div className="flex items-center gap-3">
          <span className="mono-timecode text-[11px] text-[#7d8590] w-20 text-right">
            {msToTimecode(currentTimeMs)}
          </span>
          <input
            type="range"
            min={0}
            max={totalDurationMs}
            value={currentTimeMs}
            onChange={handleSeek}
            className="flex-1 h-1.5 bg-[#21262d] rounded-lg appearance-none cursor-pointer accent-[#2ea043]"
          />
          <span className="mono-timecode text-[11px] text-[#7d8590] w-20">
            {msToTimecode(totalDurationMs)}
          </span>
        </div>

        {/* Buttons & Style Settings */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Playback Controls */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={togglePlay}
              className="p-2 rounded-xl bg-[#2ea043] hover:bg-[#238636] text-white font-semibold flex items-center justify-center transition-all shadow-md shadow-[#2ea043]/30 cursor-pointer"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
            </button>

            <button
              type="button"
              onClick={handleReset}
              className="p-2 rounded-xl bg-[#21262d] hover:bg-[#30363d] text-slate-300 transition-colors border border-[#30363d] cursor-pointer"
              title="Reset to 00:00:00"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Speed toggle */}
            <div className="flex items-center bg-[#21262d] border border-[#30363d] rounded-xl p-0.5 text-[11px]">
              {[0.75, 1, 1.25, 1.5].map((rate) => (
                <button
                  key={rate}
                  type="button"
                  onClick={() => {
                    setPlaybackRate(rate);
                    if (videoRef.current) videoRef.current.playbackRate = rate;
                  }}
                  className={`px-2 py-1 rounded-lg font-mono transition-all cursor-pointer ${
                    playbackRate === rate
                      ? 'bg-[#2ea043] text-white font-bold'
                      : 'text-[#7d8590] hover:text-white'
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>
          </div>

          {/* Subtitle Appearance Adjusters */}
          <div className="flex items-center gap-3">
            {/* Color toggle */}
            <div className="flex items-center bg-[#21262d] border border-[#30363d] rounded-xl p-0.5 text-[11px]">
              <button
                type="button"
                onClick={() => setSubtitleColor('yellow')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                  subtitleColor === 'yellow'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-[#7d8590] hover:text-[#e6edf3]'
                }`}
              >
                Yellow
              </button>
              <button
                type="button"
                onClick={() => setSubtitleColor('white')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                  subtitleColor === 'white'
                    ? 'bg-white/20 text-white border border-white/40'
                    : 'text-[#7d8590] hover:text-[#e6edf3]'
                }`}
              >
                White
              </button>
            </div>

            {/* Font size */}
            <div className="flex items-center gap-1.5 text-[#7d8590] text-xs">
              <Type className="w-3.5 h-3.5" />
              <input
                type="range"
                min={16}
                max={30}
                value={fontSize}
                onChange={(e) => setFontSize(parseInt(e.target.value, 10))}
                className="w-16 h-1 bg-[#21262d] rounded-lg appearance-none cursor-pointer accent-[#2ea043]"
                title={`Subtitle Font Size: ${fontSize}px`}
              />
            </div>

            {/* Upload Video file */}
            <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#21262d] hover:bg-[#30363d] text-slate-300 hover:text-white cursor-pointer transition-colors text-xs border border-[#30363d]">
              <Upload className="w-3.5 h-3.5 text-[#3fb950]" />
              <span>Load Video</span>
              <input
                type="file"
                accept="video/*,audio/*"
                onChange={handleVideoUpload}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
