import React from 'react';
import { UserCheck, Globe, Type } from 'lucide-react';
import { CharacterNamePolicy } from '../types/subtitle';

interface PolicyPromptModalProps {
  isOpen: boolean;
  onSelectPolicy: (policy: CharacterNamePolicy) => void;
  onCancel: () => void;
}

export const PolicyPromptModal: React.FC<PolicyPromptModalProps> = ({
  isOpen,
  onSelectPolicy,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-center space-y-5">
        <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
          <UserCheck className="w-6 h-6" />
        </div>

        <div className="space-y-1.5">
          <h3 className="text-lg font-bold text-white">
            Character Name Policy (ဇာတ်ကောင်အမည် ရွေးချယ်မှု)
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
            ဇာတ်ကောင်အမည်များကို အင်္ဂလိပ်စာလုံးအတိုင်း မူရင်းထားလိုပါသလား သို့မဟုတ် မြန်မာအသံထွက်ဖြင့် တိုက်ရိုက် မွေးစားဖလှယ်လိုပါသလား။
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          <button
            type="button"
            onClick={() => onSelectPolicy('keep_english')}
            className="p-4 rounded-xl border border-slate-700 bg-slate-950/70 hover:border-amber-500 hover:bg-amber-500/10 text-left transition-all group"
          >
            <div className="flex items-center gap-2 mb-1.5 text-white font-semibold text-sm group-hover:text-amber-300">
              <Globe className="w-4 h-4 text-amber-400" />
              <span>Keep English</span>
            </div>
            <p className="text-[11px] text-slate-400">
              မူရင်းအင်္ဂလိပ်အက္ခရာအတိုင်း ထားမည် (e.g. John, Naruto, Bruce)
            </p>
          </button>

          <button
            type="button"
            onClick={() => onSelectPolicy('burmese_transliteration')}
            className="p-4 rounded-xl border border-slate-700 bg-slate-950/70 hover:border-amber-500 hover:bg-amber-500/10 text-left transition-all group"
          >
            <div className="flex items-center gap-2 mb-1.5 text-white font-semibold text-sm group-hover:text-amber-300">
              <Type className="w-4 h-4 text-amber-400" />
              <span>Burmese Transliteration</span>
            </div>
            <p className="text-[11px] text-slate-400">
              မြန်မာအသံထွက်ဖြင့် တိုက်ရိုက်ပြန်ဆိုမည် (e.g. ဂျွန်၊ နာရူတို၊ ဘရုစ်)
            </p>
          </button>
        </div>

        <div className="pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="text-xs text-slate-500 hover:text-slate-300 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
