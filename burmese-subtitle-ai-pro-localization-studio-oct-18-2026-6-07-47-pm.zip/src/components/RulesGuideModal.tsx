import React from 'react';
import { X, ShieldCheck, Check, AlertTriangle, BookOpen, Sparkles } from 'lucide-react';

interface RulesGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesGuideModal: React.FC<RulesGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Strict Subtitle Formatting Rules</h2>
              <p className="text-xs text-slate-400">Standard rules for professional Burmese movie & anime subtitle localization</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm">
          {/* Rule 1 */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2 text-rose-400 font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-300 text-xs">1</span>
              Zero Punctuation (သင်္ကေတလုံးဝမသုံးရ)
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              စာတန်းထိုးတွင် ပုဒ်မ (။)၊ ကော်မာ/ပုဒ်ကလေး (၊)၊ မေးခွန်းသင်္ကေတ (?)၊ အာမေဍိတ် (!) လုံးဝမထည့်ရ။ ကော်မာနေရာတွင် space ခြားပြီး မေးခွန်းအတွက် မေးခွန်းပြစကားလုံးများ (လား၊ လဲ၊ တုန်း၊ ဟင်) သုံးရမည်။
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
              <div className="p-2.5 rounded-lg bg-rose-950/30 border border-rose-900/40 text-rose-300">
                <span className="font-semibold block text-[10px] text-rose-400 uppercase mb-1">❌ မှားယွင်းမှု:</span>
                မင်း ဘယ်သွားမလို့လဲ? ငါလည်း လိုက်မယ်။
              </div>
              <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-900/40 text-emerald-300">
                <span className="font-semibold block text-[10px] text-emerald-400 uppercase mb-1">✓ မှန်ကန်သော စာတန်းထိုး:</span>
                မင်း ဘယ်သွားမလို့လဲ ငါလည်း လိုက်မယ်
              </div>
            </div>
          </div>

          {/* Rule 2 */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-300 text-xs">2</span>
              Open Ellipses Allowed (...)
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              စကားထစ်ငေါ့ခြင်း၊ စကားပြတ်ကျန်ခဲ့ခြင်း သို့မဟုတ် တုံ့ဆိုင်းနေသော အသံများအတွက် အစက် ၃ စက် (<code className="text-indigo-300 font-mono">...</code>) ကို အသုံးပြုခွင့်ရှိသည်။
            </p>
            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 text-xs">
              <span className="text-emerald-400 mr-2">✓ ဥပမာ:</span>
              ဒါပေမဲ့ ငါ... မင်းကို မေ့ပစ်လို့မရဘူး...
            </div>
          </div>

          {/* Rule 3 */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-300 text-xs">3</span>
              Varied Sentence Endings (ဆက်တိုက် "တာ" မဆုံးရ)
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              စာကြောင်း ၂ ကြောင်း ဆက်တိုက် <code className="text-amber-300 font-bold">"တာ"</code> ဖြင့် အဆုံးမသတ်ရပါ။ စာတန်းထိုးအဆုံးသတ်ကို သဘာဝကျကျ အလှည့်ကျ ပြောင်းလဲပေးရမည် (တယ်၊ ပြီ၊ မယ်၊ နော်၊ ဗျာ၊ ရှင့်၊ ပေါ့၊ လေ)။
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
              <div className="p-2.5 rounded-lg bg-rose-950/30 border border-rose-900/40 text-rose-300">
                <span className="font-semibold block text-[10px] text-rose-400 uppercase mb-1">❌ ဆက်တိုက် "တာ":</span>
                ငါ မင်းကို ပြောပြခဲ့တာ<br />မင်းက နားမထောင်ခဲ့တာ
              </div>
              <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-900/40 text-emerald-300">
                <span className="font-semibold block text-[10px] text-emerald-400 uppercase mb-1">✓ ပြောင်းလဲသုံးစွဲမှု:</span>
                ငါ မင်းကို ပြောပြခဲ့တာ<br />မင်းက နားမထောင်ခဲ့ဘူးလေ (သို့) နားမထောင်ခဲ့ဘူး
              </div>
            </div>
          </div>

          {/* Rule 4 */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-300 text-xs">4</span>
              No Literary Language (စာစကားလုံး လုံးဝမသုံးရ)
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              ရုပ်ရှင်စကားပြောဟန် (Spoken Burmese) စစ်စစ်ဖြစ်ရမည်။ စာရေးဟန်စကားလုံးများဖြစ်သော <span className="text-rose-400 font-semibold">သည်၊ ၏၊ ၌၊ ၎င်း၊ သော၊ လျက်၊ ၍</span> များကို လုံးဝရှောင်ကြဉ်ရမည်။
            </p>
            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 flex items-center gap-3">
              <span>သည် → <strong>တယ်</strong></span>
              <span>•</span>
              <span>၏ → <strong>ရဲ့</strong></span>
              <span>•</span>
              <span>၌ → <strong>မှာ</strong></span>
              <span>•</span>
              <span>၎င်း → <strong>ဒီ/အဲဒီ</strong></span>
            </div>
          </div>

          {/* Rule 5 */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2 text-purple-400 font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-300 text-xs">5</span>
              Strict 1:1 Line Mapping
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              မူရင်း Subtitle index နံပါတ်နှင့် timestamp များကို တိကျစွာ ထိန်းသိမ်းထားရှိမည်။ စာကြောင်းများကို ပေါင်းစည်းခြင်း သို့မဟုတ် ခွဲထုတ်ခြင်း မပြုလုပ်ဘဲ အသံနှင့် စာတန်းထိုး အတိအကျ sync ဖြစ်စေသည်။
            </p>
          </div>

          {/* Rule 6: .ASS Style Tag Preservation */}
          <div className="p-4 rounded-xl bg-[#0e1117] border border-[#30363d] space-y-2.5">
            <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-300 text-xs">6</span>
              .ASS Style Tags &amp; Timing Integrity
            </div>
            <p className="text-xs text-[#e6edf3] leading-relaxed">
              Advanced SubStation Alpha (.ass) ဖိုင်များတွင် Header sections (<code className="text-amber-300">[Script Info]</code>, <code className="text-amber-300">[V4+ Styles]</code>) များနှင့် Dialogue အတွင်းရှိ Style override tags များ (<code className="text-amber-300">{'{\\pos(x,y)}'}</code>, <code className="text-amber-300">{'{\\fs28}'}</code>, <code className="text-amber-300">{'\\N'}</code>) ကို ၁၀၀% မူရင်းအတိုင်း ထိန်းသိမ်းပြီး စကားပြောစာသားကိုသာ သဘာဝကျကျ ဘာသာပြန်ဆိုသည်။
            </p>
          </div>

          {/* Rule 7: Two-Speaker Separation & Long Sentence Auto-Splitting */}
          <div className="p-4 rounded-xl bg-[#0e1117] border border-[#30363d] space-y-2.5">
            <div className="flex items-center gap-2 text-[#3fb950] font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-[#2ea043]/20 flex items-center justify-center text-[#3fb950] text-xs">7</span>
              Two-Speaker Split &amp; Long Sentence Auto-Splitting
            </div>
            <p className="text-xs text-[#e6edf3] leading-relaxed">
              အချိန်တစ်ခုတည်းတွင် ဇာတ်ကောင် ၂ ဦး အပြန်အလှန်ပြောပါက "- ပထမလူပြောစကား\n- ဒုတိယလူပြောစကား" ပုံစံဖြင့် ၂ ကြောင်းခွဲထုတ်ပေးပြီး၊ စာကြောင်းရှည်လွန်းပါက အမြင်ရှင်းလင်းစေရန် balanced ၂ ကြောင်း အလိုအလျောက်ခွဲပေးမည်။
            </p>
          </div>

          {/* Rule 8: No Vocal Noise Fillers */}
          <div className="p-4 rounded-xl bg-[#0e1117] border border-[#30363d] space-y-2.5">
            <div className="flex items-center gap-2 text-rose-400 font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-300 text-xs">8</span>
              No Interjections / Filler Sounds (သဘာဝမကျသော အာမေဍိတ်သံများ ဖယ်ရှားခြင်း)
            </div>
            <p className="text-xs text-[#e6edf3] leading-relaxed">
              အဟမ်း၊ ဟား၊ ဟေး၊ အား၊ um၊ uh စသော သဘာဝမကျသည့် အသံထွက်ဆူညံသံများကို သန့်စင်ဖယ်ထုတ်ပြီး ပရိုဖက်ရှင်နယ် ရုပ်ရှင်စကားပြောဟန် စစ်စစ်သာ ထည့်သွင်းသည်။
            </p>
          </div>

          {/* Rule 9: Automatic Cleaning & Filtering Rules (နာမည်နှင့် အသံဖော်ပြချက်များ အော်တိုဖျက်ခြင်း) */}
          <div className="p-4 rounded-xl bg-[#0e1117] border border-[#30363d] space-y-2.5">
            <div className="flex items-center gap-2 text-[#3fb950] font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-[#2ea043]/20 flex items-center justify-center text-[#3fb950] text-xs">9</span>
              Automatic Cleaning &amp; Filtering (နာမည်နှင့် အသံဖော်ပြချက်များ အော်တိုဖျက်ခြင်း)
            </div>
            <p className="text-xs text-[#e6edf3] leading-relaxed">
              • <strong>Parentheses Cleaning (...)</strong>: စာတန်းထိုးထဲရှိ ဇာတ်ကောင်နာမည်၊ ပြောသူအမှတ်အသား သို့မဟုတ် စတိတ်ညွှန်ကြားချက်များ (ဥပမာ- <code className="text-emerald-300">(John)</code>, <code className="text-emerald-300">(မင်းသား)</code>, <code className="text-emerald-300">(whispering)</code>) ကို ဘာသာပြန်တွင် မပါဝင်စေရန် အလိုအလျောက်ဖျက်ထုတ်ပေးသည်။ (.ass style tags များဖြစ်သော <code className="text-amber-300">{'{...}'}</code> ကိုမူ အပြည့်အဝ ထိန်းသိမ်းထားသည်)<br />
              • <strong>Brackets Cleaning [...]</strong>: စတိတ်လှုပ်ရှားမှုနှင့် အသံဖော်ပြချက်များ (ဥပမာ- <code className="text-emerald-300">[ရယ်လျက်]</code>, <code className="text-emerald-300">[သက်ပြင်းချသံ]</code>, <code className="text-emerald-300">[Music plays]</code>) ကို အလိုအလျောက် detect ပြုလုပ်ပြီး သန့်စင်ဖယ်ရှားပေးသည်။
            </p>
          </div>

          {/* Rule 10: 17 Movie & Show Genres & Universal 2-Speaker Split */}
          <div className="p-4 rounded-xl bg-[#0e1117] border border-[#30363d] space-y-2.5">
            <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-300 text-xs">10</span>
              17 Movie &amp; Show Genres (Universal 2-Speaker Split Enabled)
            </div>
            <p className="text-xs text-[#e6edf3] leading-relaxed">
              Preset အားလုံး (၁၇ မျိုးစလုံး) တွင် <strong>Two-Speaker Split စနစ် အလိုအလျောက် ပါဝင်သည်</strong> (ဖျက်ရန်ခလုတ် 🗑️ လည်း ပါဝင်သည်)။ ရုပ်ရှင်နှင့် ရှိုးအမျိုးအစား ၁၇ မျိုးအလိုက် ဘာသာပြန်ဟန်ကို ပြောင်းလဲပေးပါသည်:
            </p>
            <div className="flex flex-wrap gap-1.5 pt-1 text-[11px]">
              {[
                'Action', 'Drama', 'Comedy', 'Romance', 'Horror', 'Thriller', 'Crime',
                'Historical', 'Kdrama', 'Anime', 'Animation', 'Adult', 'Supernatural',
                'Variety Show', 'Reality Show', 'Singing Competition', 'Talent Show'
              ].map((genre) => (
                <span key={genre} className="px-2 py-0.5 rounded-md bg-[#161b22] border border-[#30363d] text-emerald-300 font-medium">
                  {genre}
                </span>
              ))}
            </div>
          </div>

          {/* Rule 11: Multilingual Translation Support */}
          <div className="p-4 rounded-xl bg-[#0e1117] border border-[#30363d] space-y-2.5">
            <div className="flex items-center gap-2 text-sky-400 font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-sky-500/20 flex items-center justify-center text-sky-300 text-xs">11</span>
              Multilingual Translation Support (ဘာသာစကားစုံမှ ဘာသာပြန်ခြင်း)
            </div>
            <p className="text-xs text-[#e6edf3] leading-relaxed">
              ဂျပန်၊ ကိုရီးယား၊ အင်္ဂလိပ်၊ တရုတ်၊ ထိုင်းစသော ဘာသာစကားမျိုးစုံမှ တိုက်ရိုက် သဘာဝကျသော ရုပ်ရှင်စကားပြောဟန် မြန်မာစာတန်းထိုးသို့ ပြောင်းလဲပေးသည်။
            </p>
            <div className="text-xs text-[#7d8590] space-y-1">
              <div>• <strong>Japanese</strong>: Honorifics (-san, -kun, -sama, -sensei) များကို ရင်းနှီးမှုအလိုက် (ကို..., မမ..., ဆရာ) သဘာဝကျကျ ပြောင်းလဲသည်။</div>
              <div>• <strong>Korean</strong>: Oppa, Hyung, Unnie, Sunbae, Daeponim စသည်တို့ကို ဆက်ဆံရေးအလိုက် သဘာဝမြန်မာစကားပြော ပြုလုပ်ပေးသည်။</div>
              <div>• <strong>English, Chinese, Thai</strong>: ဒေသန္တရစကား၊ အီဒီယမ်နှင့် စကားပုံများကို တိုက်ရိုက်စကားလုံးချင်းမပြန်ဘဲ သဘာဝကျသော အဓိပ္ပာယ်တူ စကားပြောဟန်ဖြင့် လိုကယ်လိုက်ဇေးရှင်း ပြုလုပ်ပေးသည်။</div>
            </div>
          </div>

          {/* Rule 12: Supported Modern Gemini Engines */}
          <div className="p-4 rounded-xl bg-[#0e1117] border border-[#30363d] space-y-2.5">
            <div className="flex items-center gap-2 text-[#3fb950] font-semibold text-xs tracking-wider uppercase">
              <span className="w-5 h-5 rounded-full bg-[#2ea043]/20 flex items-center justify-center text-[#3fb950] text-xs">12</span>
              Supported Modern Gemini Engines (နောက်ဆုံးပေါ် AI မော်ဒယ် ၄ မျိုး)
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-[#161b22] border border-[#30363d]">
                <span className="font-bold text-white block">Gemini 3.8 Flash</span>
                <span className="text-[11px] text-[#7d8590]">Latest high-speed workhorse, superior reasoning &amp; multilingual context</span>
              </div>
              <div className="p-2.5 rounded-lg bg-[#161b22] border border-[#30363d]">
                <span className="font-bold text-white block">Gemini 3.7 Flash</span>
                <span className="text-[11px] text-[#7d8590]">Advanced reasoning and precise subtitle context understanding</span>
              </div>
              <div className="p-2.5 rounded-lg bg-[#161b22] border border-[#30363d]">
                <span className="font-bold text-white block">Gemini 3.1 Pro Preview</span>
                <span className="text-[11px] text-[#7d8590]">Deepest reasoning for complex cultural idioms &amp; nuances</span>
              </div>
              <div className="p-2.5 rounded-lg bg-[#161b22] border border-[#30363d]">
                <span className="font-bold text-white block">Gemini 2.5 Pro</span>
                <span className="text-[11px] text-[#7d8590]">Stable and highly reliable long-context translation engine</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#30363d] flex justify-end bg-[#0e1117]/80">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-white bg-[#2ea043] hover:bg-[#238636] rounded-xl transition-all cursor-pointer shadow-md shadow-[#2ea043]/20"
          >
            နားလည်ပါပြီ (Got it)
          </button>
        </div>
      </div>
    </div>
  );
};
