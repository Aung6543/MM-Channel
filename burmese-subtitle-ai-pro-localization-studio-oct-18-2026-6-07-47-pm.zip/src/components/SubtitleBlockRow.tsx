import React, { useState } from 'react';
import { Play, Sparkles, Wand2, AlertCircle, AlertTriangle, Check, RefreshCw, ChevronDown, ChevronUp } from 'lucide-react';
import { SubtitleBlock, ValidationIssue } from '../types/subtitle';
import { autoCleanSubtitleText } from '../utils/burmeseValidator';

interface SubtitleBlockRowProps {
  block: SubtitleBlock;
  index: number;
  isRevealed: boolean;
  hasCompletedTranslation?: boolean;
  onToggleReveal: (id: number) => void;
  onUpdateText: (id: number, newBurmese: string) => void;
  onJumpToTime: (ms: number) => void;
  genre: string;
  pronouns: string;
}

export const SubtitleBlockRow: React.FC<SubtitleBlockRowProps> = ({
  block,
  index,
  isRevealed,
  hasCompletedTranslation = false,
  onToggleReveal,
  onUpdateText,
  onJumpToTime,
  genre,
  pronouns,
}) => {
  const [isAlternativesOpen, setIsAlternativesOpen] = useState(false);
  const [isLoadingAlternatives, setIsLoadingAlternatives] = useState(false);
  const [alternatives, setAlternatives] = useState<Array<{ style: string; burmeseText: string; explanation: string }>>([]);

  const issues = block.issues || [];
  const hasErrors = issues.some((i) => i.severity === 'error');
  const hasWarnings = issues.some((i) => i.severity === 'warning');

  // Multi-speaker detection (e.g. begins with '- ' or has two distinct lines)
  const isTwoSpeaker = block.sourceText.includes('\n-') || block.sourceText.trim().startsWith('-');
  const isLong = block.sourceText.length > 50 || (block.burmeseText && block.burmeseText.length > 50);

  const handleFetchAlternatives = async () => {
    if (alternatives.length > 0) {
      setIsAlternativesOpen(!isAlternativesOpen);
      return;
    }

    setIsLoadingAlternatives(true);
    setIsAlternativesOpen(true);
    try {
      const res = await fetch('/api/rephrase-line', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          sourceText: block.sourceText,
          currentBurmese: block.burmeseText,
          genre,
          pronouns,
        }),
      });
      const data = await res.json();
      if (data.alternatives) {
        setAlternatives(data.alternatives);
      }
    } catch (err) {
      console.error('Failed to get alternatives', err);
    } finally {
      setIsLoadingAlternatives(false);
    }
  };

  const handleApplyAlternative = (burmeseText: string) => {
    onUpdateText(block.id, burmeseText);
    setIsAlternativesOpen(false);
  };

  const handleSingleAutoClean = () => {
    const cleaned = autoCleanSubtitleText(block.burmeseText);
    onUpdateText(block.id, cleaned);
  };

  return (
    <div
      className={`rounded-2xl border transition-all p-4 space-y-3 shadow-md ${
        hasErrors
          ? 'bg-[#161b22] border-rose-800/60 hover:border-rose-700'
          : hasWarnings
          ? 'bg-[#161b22] border-amber-800/60 hover:border-amber-700'
          : 'bg-[#161b22] border-[#30363d] hover:border-[#484f58]'
      }`}
    >
      {/* Top Header: ID & Timecodes */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono px-2.5 py-0.5 rounded-lg bg-[#21262d] border border-[#30363d] text-[#e6edf3] font-bold text-[11px]">
            #{block.id}
          </span>
          <button
            type="button"
            onClick={() => onJumpToTime(block.startMs)}
            className="flex items-center gap-1.5 mono-timecode text-[#3fb950] hover:text-[#56d364] hover:underline transition-colors font-medium cursor-pointer"
            title="Jump to time in preview player"
          >
            <Play className="w-3 h-3 fill-[#3fb950]" />
            <span>{block.startTime} → {block.endTime}</span>
          </button>

          {isTwoSpeaker && (
            <span className="text-[10px] px-2 py-0.5 rounded-md bg-indigo-950/80 border border-indigo-700/50 text-indigo-300 font-medium">
              👥 2-Speaker Split
            </span>
          )}

          {isLong && (
            <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-950/80 border border-amber-700/50 text-amber-300 font-medium">
              📏 Long Line
            </span>
          )}

          {block.assStyle && (
            <span className="font-mono text-[10px] px-2 py-0.5 rounded-md bg-[#21262d] border border-[#30363d] text-amber-300">
              Style: {block.assStyle}
            </span>
          )}
          {block.assActor && (
            <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#21262d] border border-[#30363d] text-slate-300">
              Actor: {block.assActor}
            </span>
          )}
          {block.assOverrideTags && (
            <span
              className="font-mono text-[10px] px-2 py-0.5 rounded-md bg-emerald-950/60 border border-emerald-800/40 text-emerald-300 truncate max-w-[150px]"
              title={block.assOverrideTags}
            >
              Tags: {block.assOverrideTags}
            </span>
          )}
        </div>

        {/* Row actions */}
        <div className="flex items-center gap-2">
          {issues.length > 0 && (
            <button
              type="button"
              onClick={handleSingleAutoClean}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/15 text-amber-300 hover:bg-amber-500/25 border border-amber-500/30 text-[11px] font-medium transition-colors cursor-pointer"
              title="Auto clean punctuation and literary particles"
            >
              <Wand2 className="w-3 h-3" />
              <span>Clean Rule</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleFetchAlternatives}
            disabled={isLoadingAlternatives || !block.burmeseText}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
              isAlternativesOpen
                ? 'bg-[#2ea043] text-white shadow-sm'
                : 'bg-[#21262d] text-slate-200 hover:text-white hover:bg-[#30363d] border border-[#30363d]'
            }`}
            title="Explore natural spoken alternative styles"
          >
            {isLoadingAlternatives ? (
              <RefreshCw className="w-3 h-3 animate-spin text-[#3fb950]" />
            ) : (
              <Sparkles className="w-3 h-3 text-[#3fb950]" />
            )}
            <span>Styles</span>
            {isAlternativesOpen ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* Grid: Original vs Spoken Burmese */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {/* Left: Source Text */}
        <div className="p-3.5 rounded-xl bg-[#0e1117] border border-[#30363d] flex flex-col justify-between">
          <div>
            <span className="block text-[10px] uppercase tracking-wider font-semibold text-[#7d8590] mb-1.5">
              Original Dialogue (မူရင်းစကားပြော)
            </span>
            <p className="text-sm text-[#e6edf3] whitespace-pre-line leading-relaxed font-normal">
              {block.sourceText}
            </p>
          </div>
          <div className="pt-2 text-[10px] text-[#7d8590] flex items-center justify-between">
            <span>{block.sourceText.length} characters</span>
            {block.sourceText.includes('\n') && <span>Multi-line</span>}
          </div>
        </div>

        {/* Right: Burmese Translation with Collapsible Display Control Rule */}
        <div className="p-3.5 rounded-xl bg-[#0e1117] border border-[#30363d] flex flex-col justify-between space-y-2">
          {/* Header */}
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-[#3fb950] flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#2ea043] inline-block animate-pulse"></span>
              Spoken Burmese Subtitle (ရုပ်ရှင်စကားပြောဟန်)
            </span>

            {hasCompletedTranslation && block.burmeseText ? (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/70 border border-[#2ea043]/40 text-[#3fb950] font-medium">
                {block.burmeseText.length} chars
              </span>
            ) : (
              <span className="text-[10px] text-[#7d8590]">🔒 ဘာသာပြန်ပြီးမှ ပေါ်မည်</span>
            )}
          </div>

          {/* Display Control Rule: Strictly hidden / placeholder until translation finishes */}
          {!hasCompletedTranslation || !block.burmeseText ? (
            <div className="py-4 px-3 text-center text-xs text-[#7d8590] border border-dashed border-[#30363d] rounded-xl flex flex-col items-center justify-center gap-1 bg-[#0e1117]/60">
              <span className="text-slate-300 font-medium">🔒 ဘာသာပြန်ရန် စောင့်ဆိုင်းနေပါသည်...</span>
              <span className="text-[11px] text-[#7d8590]">Hidden until translation completes • အပေါ်ရှိ Translate Now ကိုနှိပ်ပါ</span>
            </div>
          ) : !isRevealed ? (
            /* Collapsed State behind interaction toggle button */
            <div className="py-2.5 px-3 bg-[#161b22] border border-[#30363d] rounded-xl flex flex-col sm:flex-row items-center justify-between gap-2.5 transition-all">
              <div className="flex items-center gap-2 text-xs">
                <span className="w-2 h-2 rounded-full bg-[#2ea043]"></span>
                <span className="text-slate-300 font-medium">ဘာသာပြန်ပြီးသား စာတန်းထိုးရှိပါသည်</span>
                <span className="text-[11px] text-[#7d8590]">({block.burmeseText.split('\n').length} ကြောင်း)</span>
              </div>

              <button
                type="button"
                onClick={() => onToggleReveal(block.id)}
                className="w-full sm:w-auto px-3.5 py-1.5 bg-[#2ea043] hover:bg-[#238636] text-white text-xs font-semibold rounded-lg shadow-md shadow-[#2ea043]/20 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                title="Click to reveal translated Burmese text"
              >
                <span>👀 ဘာသာပြန်စာသားကို ကြည့်ရန် / ဖွင့်ရန်</span>
              </button>
            </div>
          ) : (
            /* Expanded / Revealed State */
            <div className="space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-1">
                <span className="text-[11px] text-[#7d8590]">၁၀၀% စကားပြောဟန် • သုညပုဒ်မ</span>
                <button
                  type="button"
                  onClick={() => onToggleReveal(block.id)}
                  className="text-[11px] text-[#7d8590] hover:text-white px-2 py-0.5 rounded hover:bg-[#21262d] transition-colors flex items-center gap-1 cursor-pointer"
                  title="Hide translation output"
                >
                  <span>🙈 ဝှက်ထားရန်</span>
                </button>
              </div>

              <textarea
                rows={block.burmeseText.split('\n').length > 1 ? 3 : 2}
                value={block.burmeseText}
                onChange={(e) => onUpdateText(block.id, e.target.value)}
                placeholder="မြန်မာစကားပြော စာတန်းထိုး..."
                className="w-full bg-[#161b22] border border-[#30363d] focus:border-[#2ea043] rounded-xl p-3 text-sm text-[#e6edf3] burmese-text placeholder-[#7d8590] focus:outline-none transition-colors"
              />

              {/* Issue feedback chips */}
              {issues.length > 0 && (
                <div className="space-y-1 pt-1">
                  {issues.map((issue, idx) => (
                    <div
                      key={idx}
                      className={`text-[11px] px-2.5 py-1 rounded-lg flex items-start gap-1.5 ${
                        issue.severity === 'error'
                          ? 'bg-rose-950/40 text-rose-300 border border-rose-900/40'
                          : 'bg-amber-950/40 text-amber-300 border border-amber-900/40'
                      }`}
                    >
                      {issue.severity === 'error' ? (
                        <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-rose-400" />
                      ) : (
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
                      )}
                      <span>
                        {issue.message}{' '}
                        {issue.suggestion && (
                          <span className="font-semibold text-white underline ml-1">
                            {issue.suggestion}
                          </span>
                        )}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {block.notes && (
                <p className="text-[11px] text-[#7d8590] italic bg-[#161b22] px-2.5 py-1.5 rounded-lg border border-[#30363d]">
                  💡 {block.notes}
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Alternative Spoken Styles Panel */}
      {isAlternativesOpen && (
        <div className="p-3.5 bg-[#0e1117] rounded-xl border border-[#30363d] space-y-2 mt-2 animate-in fade-in">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-[#3fb950] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#3fb950]" />
              Stylistic Spoken Variations (စကားပြောဟန် ရွေးချယ်မှုများ)
            </span>
            <span className="text-[10px] text-[#7d8590]">Click any option to apply</span>
          </div>

          {isLoadingAlternatives ? (
            <div className="py-4 text-center text-xs text-[#7d8590] flex items-center justify-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-[#3fb950]" />
              <span>Generating natural spoken phrasing variations...</span>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-2 pt-1">
              {alternatives.map((alt, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleApplyAlternative(alt.burmeseText)}
                  className="p-3 rounded-xl border border-[#30363d] bg-[#161b22] hover:border-[#2ea043] hover:bg-[#1c2128] text-left transition-all group cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-semibold text-[#3fb950] group-hover:text-[#56d364]">
                      {alt.style}
                    </span>
                    <span className="text-[10px] text-[#7d8590] group-hover:text-[#3fb950] flex items-center gap-1">
                      <Check className="w-3 h-3" /> Select
                    </span>
                  </div>
                  <p className="text-xs text-[#e6edf3] burmese-text font-medium">
                    {alt.burmeseText}
                  </p>
                  <p className="text-[10px] text-[#7d8590] mt-0.5">
                    {alt.explanation}
                  </p>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
