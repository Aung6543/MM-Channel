import React from 'react';
import { HelpCircle, Check, Sparkles, MessageCircleQuestion } from 'lucide-react';
import { DetectedAmbiguity } from '../types/subtitle';

interface AiClarificationPanelProps {
  ambiguities: DetectedAmbiguity[];
  onResolve: (blockId: number, selectedText: string) => void;
  onDismiss: (blockId: number) => void;
}

export const AiClarificationPanel: React.FC<AiClarificationPanelProps> = ({
  ambiguities,
  onResolve,
  onDismiss,
}) => {
  if (ambiguities.length === 0) return null;

  return (
    <div className="bg-gradient-to-br from-indigo-950/30 to-slate-900 border border-indigo-900/40 rounded-2xl p-4 shadow-xl space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
            <MessageCircleQuestion className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-white flex items-center gap-1.5">
              Dialogue Context Clarification Needed
              <span className="px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px]">
                {ambiguities.length}
              </span>
            </h4>
            <p className="text-[11px] text-slate-400">
              The AI flagged subtle nuances or slang that could have multiple Burmese interpretations.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-2.5 pt-1">
        {ambiguities.map((item) => (
          <div
            key={item.blockId}
            className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl space-y-2 text-xs"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-indigo-400 text-[11px] font-semibold">
                Subtitle #{item.blockId}
              </span>
              <span className="text-[11px] text-slate-400 italic">
                "{item.sourcePhrase}"
              </span>
            </div>

            <p className="text-slate-300 text-xs">
              ❓ {item.query}
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              {item.options.map((opt, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => onResolve(item.blockId, opt)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    item.resolvedChoice === opt
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-slate-900 border border-slate-800 text-slate-300 hover:border-indigo-500 hover:text-white'
                  }`}
                >
                  <span className="burmese-text">{opt}</span>
                </button>
              ))}

              <button
                type="button"
                onClick={() => onDismiss(item.blockId)}
                className="text-[11px] text-slate-500 hover:text-slate-400 px-2 py-1"
              >
                Dismiss
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
