import React from 'react';
import { Settings, Film, ShieldCheck, MessageSquareCode, Cpu, Layers, Globe, ChevronDown } from 'lucide-react';
import { CharacterNamePolicy, AIModelProfile, AIModelId, SourceLanguage, SubtitleFormat } from '../types/subtitle';

interface NavbarProps {
  characterPolicy: CharacterNamePolicy;
  onPolicyChange: (policy: CharacterNamePolicy) => void;
  subtitleFormat: SubtitleFormat;
  onFormatChange: (format: SubtitleFormat) => void;
  modelProfile: AIModelProfile;
  onModelProfileChange: (profile: AIModelProfile) => void;
  selectedModel?: AIModelId;
  onModelChange?: (model: AIModelId) => void;
  sourceLanguage?: SourceLanguage;
  onLanguageChange?: (lang: SourceLanguage) => void;
  onOpenSettings: () => void;
  onOpenGuide: () => void;
  onToggleChat: () => void;
  isChatOpen: boolean;
  totalBlocks: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  characterPolicy,
  onPolicyChange,
  subtitleFormat,
  onFormatChange,
  modelProfile,
  onModelProfileChange,
  selectedModel = 'gemini-3.8-flash',
  onModelChange,
  sourceLanguage = 'auto_detect',
  onLanguageChange,
  onOpenSettings,
  onOpenGuide,
  onToggleChat,
  isChatOpen,
  totalBlocks,
}) => {
  const currentModel = selectedModel || (modelProfile as AIModelId) || 'gemini-3.8-flash';

  const handleSelectModel = (m: AIModelId) => {
    if (onModelChange) onModelChange(m);
    onModelProfileChange(m);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-[#30363d] bg-[#0e1117]/95 backdrop-blur-md px-4 lg:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Badge */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#2ea043] via-emerald-400 to-[#161b22] p-[2px] shadow-lg shadow-[#2ea043]/20">
            <div className="w-full h-full bg-[#0e1117] rounded-[10px] flex items-center justify-center">
              <Film className="w-5 h-5 text-[#3fb950]" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg tracking-tight text-white flex items-center gap-1.5">
                MM Channel AI Subtitles
                <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold bg-[#2ea043]/15 text-[#3fb950] border border-[#2ea043]/30">
                  Multilingual AI
                </span>
              </span>
            </div>
            <p className="text-xs text-[#7d8590] hidden sm:block">
              ၁၀၀% ရုပ်ရှင်စကားပြောဟန် • Zero Punctuation • Universal 2-Speaker Split • Clean Dialogue
            </p>
          </div>
        </div>

        {/* Central Controls: Model Selector, Language, Format, Name Policy */}
        <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap">
          {/* Format Switcher (.SRT vs .ASS) */}
          <div className="flex items-center bg-[#161b22] border border-[#30363d] rounded-xl p-1 text-xs">
            <button
              type="button"
              onClick={() => onFormatChange('srt')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                subtitleFormat === 'srt'
                  ? 'bg-[#2ea043] text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Standard SubRip .SRT format"
            >
              .SRT
            </button>
            <button
              type="button"
              onClick={() => onFormatChange('ass')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all flex items-center gap-1 cursor-pointer ${
                subtitleFormat === 'ass'
                  ? 'bg-[#2ea043] text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Advanced SubStation Alpha .ASS format"
            >
              <Layers className="w-3 h-3" />
              <span>.ASS</span>
            </button>
          </div>

          {/* Manual AI Model Selector (မိမိစိတ်ကြိုက် AI Model တိုက်ရိုက်ရွေးချယ်ရန်) */}
          <div className="flex items-center bg-[#161b22] border border-[#30363d] hover:border-[#2ea043] rounded-xl px-2.5 py-1 text-xs shadow-sm transition-colors">
            <Cpu className="w-3.5 h-3.5 text-[#3fb950] mr-1.5 shrink-0" />
            <select
              value={selectedModel || 'gemini-3.8-flash'}
              onChange={(e) => {
                if (onModelChange) {
                  onModelChange(e.target.value as AIModelId);
                }
                if (onModelProfileChange) {
                  onModelProfileChange(e.target.value as AIModelId);
                }
              }}
              className="bg-transparent text-[#e6edf3] font-semibold text-[11px] focus:outline-none cursor-pointer pr-1"
              title="ရွေးချယ်ထားသော Premium AI Model"
            >
              <option value="gemini-3.8-flash" className="bg-[#161b22] text-white">⚡ Gemini 3.8 Flash (အမြန်နှုန်း အထူးကောင်းမွန်)</option>
              <option value="gemini-3.7-flash" className="bg-[#161b22] text-white">🧠 Gemini 3.7 Flash (စာတန်းထိုး အထားအသို ခွဲခြမ်းစိတ်ဖြာ)</option>
              <option value="gemini-3.1-pro-preview" className="bg-[#161b22] text-white">✨ Gemini 3.1 Pro Preview (ယဉ်ကျေးမှုဆိုင်ရာ အသုံးအနှုန်း)</option>
              <option value="gemini-2.5-pro" className="bg-[#161b22] text-white">📦 Gemini 2.5 Pro (စကားပြောအရှည်ကြီးများနှင့် တည်ငြိမ်မှု)</option>
              <option value="gpt-4o" className="bg-[#161b22] text-white">🚀 GPT-4o (Flagship စကားပြန်စနစ်)</option>
              <option value="claude-3.5-sonnet" className="bg-[#161b22] text-white">🎭 Claude 3.5 Sonnet (ချောမွေ့သဘာဝကျသော ရုပ်ရှင်စကား)</option>
              <option value="llama-3.1-405b" className="bg-[#161b22] text-white">🦙 Llama 3.1 405B (ဘာသာစကားဆိုင်ရာ အနက်ကြွယ်ဝမှု)</option>
            </select>
          </div>

          {/* Multilingual Source Language Quick Indicator/Selector */}
          {onLanguageChange && (
            <div className="hidden sm:flex items-center bg-[#161b22] border border-[#30363d] rounded-xl p-1 text-xs">
              {(['auto_detect', 'Japanese', 'Korean', 'English', 'Chinese', 'Thai'] as SourceLanguage[]).map((lang) => {
                const labelMap: Record<string, string> = {
                  auto_detect: '🌐 Auto',
                  Japanese: '🇯🇵 JA',
                  Korean: '🇰🇷 KO',
                  English: '🇺🇸 EN',
                  Chinese: '🇨🇳 ZH',
                  Thai: '🇹🇭 TH',
                };
                return (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => onLanguageChange(lang)}
                    className={`px-2 py-0.8 rounded-lg text-[10px] font-medium transition-all cursor-pointer ${
                      sourceLanguage === lang
                        ? 'bg-[#2ea043]/20 text-[#3fb950] border border-[#2ea043]/40 font-semibold shadow-sm'
                        : 'text-[#7d8590] hover:text-[#e6edf3]'
                    }`}
                    title={`Source Language: ${lang}`}
                  >
                    {labelMap[lang]}
                  </button>
                );
              })}
            </div>
          )}

          {/* Character Name Policy Switch */}
          <div className="flex items-center bg-[#161b22] border border-[#30363d] rounded-xl p-1 text-xs">
            <button
              type="button"
              onClick={() => onPolicyChange('keep_english')}
              className={`px-2.5 py-1 rounded-lg font-medium text-[11px] transition-all cursor-pointer ${
                characterPolicy === 'keep_english'
                  ? 'bg-[#2ea043]/20 text-[#3fb950] border border-[#2ea043]/40 shadow-sm'
                  : 'text-[#7d8590] hover:text-[#e6edf3]'
              }`}
              title="Keep names in English: John, Naruto, Bruce"
            >
              English
            </button>
            <button
              type="button"
              onClick={() => onPolicyChange('burmese_transliteration')}
              className={`px-2.5 py-1 rounded-lg font-medium text-[11px] transition-all cursor-pointer ${
                characterPolicy === 'burmese_transliteration'
                  ? 'bg-[#2ea043]/20 text-[#3fb950] border border-[#2ea043]/40 shadow-sm'
                  : 'text-[#7d8590] hover:text-[#e6edf3]'
              }`}
              title="Transliterate to Burmese: ဂျွန်၊ နာရူတို၊ ဘရုစ်"
            >
              Burmese
            </button>
          </div>

          {/* Guide / Strict Rules button */}
          <button
            type="button"
            onClick={onOpenGuide}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-xl bg-[#161b22] border border-[#30363d] hover:border-[#2ea043] text-slate-300 hover:text-white transition-all cursor-pointer"
            title="View Strict Subtitle Rules"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#3fb950]" />
            <span className="hidden sm:inline">Rules</span>
          </button>

          {/* AI Localization Chat toggle */}
          <button
            type="button"
            onClick={onToggleChat}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-xl transition-all cursor-pointer ${
              isChatOpen
                ? 'bg-[#2ea043] text-white shadow-md shadow-[#2ea043]/20'
                : 'bg-[#161b22] border border-[#30363d] text-slate-300 hover:text-white hover:border-[#2ea043]'
            }`}
            title="Open MM Channel AI Assistant Chat"
          >
            <MessageSquareCode className="w-3.5 h-3.5 text-[#3fb950]" />
            <span className="hidden sm:inline">Chat</span>
          </button>

          {/* Settings button */}
          <button
            type="button"
            onClick={onOpenSettings}
            className="p-2 text-slate-400 hover:text-white hover:bg-[#21262d] rounded-xl transition-all border border-transparent hover:border-[#30363d] cursor-pointer"
            title="Project Localization Settings & Genres"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
