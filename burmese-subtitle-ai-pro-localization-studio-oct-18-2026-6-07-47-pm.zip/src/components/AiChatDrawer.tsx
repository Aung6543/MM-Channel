import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, User, Sparkles, Copy, Check, RefreshCw } from 'lucide-react';
import { SubtitleBlock } from '../types/subtitle';
import { generateSrtContent } from '../utils/srtParser';

interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

interface AiChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  blocks: SubtitleBlock[];
}

export const AiChatDrawer: React.FC<AiChatDrawerProps> = ({ isOpen, onClose, blocks }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      content: `မင်္ဂလာပါ! ကျွန်တော်ကတော့ "MM Channel AI Subtitles" ဖြစ်ပါတယ်။ 
ရုပ်ရှင်၊ ဇာတ်လမ်းတွဲ၊ Kdrama၊ Anime နှင့် Reality/Variety Show များ၏ dialogues များကို သဘာဝကျသော ရုပ်ရှင်စကားပြောဟန် (၁၀၀% Spoken Burmese၊ Zero Punctuation၊ Two-Speaker Split၊ Long Sentence Auto-Split နှင့် အပိုအသံများ ဖယ်ရှားခြင်း) ဖြင့် အကောင်းဆုံး ဘာသာပြန်ပေးရန် အသင့်ရှိပါသည်။

ဇာတ်ကောင် စကားပြောဟန်၊ နာမ်စား (ငါ/မင်း၊ ကျုပ်/ခင်ဗျား၊ ကိုယ်/နင်)၊ ဇာတ်ကောင်အမည် မူဝါဒ သို့မဟုတ် အသုံးအနှုန်းသတ်မှတ်ချက်များကို မေးမြန်းနိုင်ပါတယ်။`,
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userText = input.trim();
    setInput('');
    const newHistory: ChatMessage[] = [...messages, { role: 'user', content: userText }];
    setMessages(newHistory);
    setIsLoading(true);

    // Provide excerpt of current SRT context if available
    const currentSrtContext = blocks.length > 0
      ? generateSrtContent(blocks.slice(0, 10), true)
      : '';

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          message: userText,
          history: messages,
          currentSrtContext,
        }),
      });

      const data = await res.json();
      if (data.reply) {
        setMessages([...newHistory, { role: 'model', content: data.reply }]);
      } else {
        setMessages([...newHistory, { role: 'model', content: 'တောင်းပန်ပါတယ်၊ အဖြေထုတ်ယူရာတွင် ချို့ယွင်းချက်ရှိခဲ့ပါသည်။ ကျေးဇူးပြု၍ ထပ်မံကြိုးစားပေးပါ။' }]);
      }
    } catch (err: any) {
      setMessages([...newHistory, { role: 'model', content: `Error: ${err.message || 'Server error'}` }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyMessage = async (content: string, idx: number) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedIndex(idx);
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] bg-[#161b22] border-l border-[#30363d] shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="px-5 py-4 border-b border-[#30363d] flex items-center justify-between bg-[#0e1117]/90">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#2ea043] to-[#161b22] border border-[#2ea043]/30 flex items-center justify-center text-[#3fb950] shadow-sm">
            <Bot className="w-4 h-4 text-[#3fb950]" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">MM Channel AI Assistant</h3>
            <p className="text-[11px] text-[#7d8590]">Natural Spoken Burmese • Subtitle Specialist</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-white hover:bg-[#21262d] rounded-lg transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 p-4 overflow-y-auto space-y-4 text-xs">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[88%] p-3.5 rounded-2xl relative group ${
                m.role === 'user'
                  ? 'bg-[#2ea043] text-white rounded-br-none shadow-sm'
                  : 'bg-[#0e1117] border border-[#30363d] text-[#e6edf3] rounded-bl-none'
              }`}
            >
              <div className="burmese-text whitespace-pre-wrap leading-relaxed">
                {m.content}
              </div>

              {m.role === 'model' && (
                <button
                  type="button"
                  onClick={() => handleCopyMessage(m.content, idx)}
                  className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1 rounded bg-[#21262d] text-slate-400 hover:text-white transition-opacity cursor-pointer border border-[#30363d]"
                  title="Copy response"
                >
                  {copiedIndex === idx ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>
              )}
            </div>
            <span className="text-[10px] text-[#7d8590] mt-1 px-1">
              {m.role === 'user' ? 'You' : 'MM Channel AI'}
            </span>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 p-3 bg-[#0e1117] rounded-2xl border border-[#30363d] text-[#7d8590] w-fit">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#3fb950]" />
            <span className="text-[11px]">စကားပြောဟန် စဉ်းစားနေပါသည်...</span>
          </div>
        )}
      </div>

      {/* Suggested Quick Prompts */}
      <div className="px-4 py-2 border-t border-[#30363d] bg-[#0e1117]/40 flex flex-wrap gap-1.5 text-[11px]">
        <button
          type="button"
          onClick={() => setInput('Translate this Kdrama dialogue with 2-speaker split: "- Did you meet the director?\n- Yes, he refused to talk."')}
          className="px-2 py-1 bg-[#21262d] hover:bg-[#30363d] text-slate-300 rounded-md truncate max-w-[220px] cursor-pointer border border-[#30363d]"
        >
          Kdrama 2-speaker dialogue
        </button>
        <button
          type="button"
          onClick={() => setInput('Check my subtitle line for zero punctuation and consecutive "တာ" rule')}
          className="px-2 py-1 bg-[#21262d] hover:bg-[#30363d] text-slate-300 rounded-md cursor-pointer border border-[#30363d]"
        >
          Check formatting rules
        </button>
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="p-3 border-t border-[#30363d] bg-[#0e1117]">
        <div className="flex items-center gap-2 bg-[#161b22] border border-[#30363d] rounded-xl p-1.5 focus-within:border-[#2ea043]">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="မေးမြန်းလိုသည်များကို ရိုက်ထည့်ပါ..."
            className="flex-1 bg-transparent px-2 text-xs text-white placeholder-[#7d8590] focus:outline-none burmese-text"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="p-2 rounded-lg bg-[#2ea043] hover:bg-[#238636] disabled:opacity-40 text-white transition-colors cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </form>
    </div>
  );
};
