import React, { useState } from 'react';
import { X, Copy, Check, Download, FileText, ShieldCheck, Layers } from 'lucide-react';
import { SubtitleBlock, SubtitleFormat } from '../types/subtitle';
import { generateSrtContent, formatAsSrtCodeBlock } from '../utils/srtParser';
import { generateAssContent, formatAsAssCodeBlock, DEFAULT_ASS_HEADERS } from '../utils/assParser';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  blocks: SubtitleBlock[];
  defaultFormat?: SubtitleFormat;
  assHeaders?: string;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  blocks,
  defaultFormat = 'srt',
  assHeaders = DEFAULT_ASS_HEADERS,
}) => {
  const [activeTab, setActiveTab] = useState<SubtitleFormat>(defaultFormat);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const rawSrt = generateSrtContent(blocks, true);
  const rawAss = generateAssContent(blocks, assHeaders, true);

  const markdownSrt = formatAsSrtCodeBlock(blocks, true);
  const markdownAss = formatAsAssCodeBlock(blocks, assHeaders, true);

  const currentRaw = activeTab === 'ass' ? rawAss : rawSrt;
  const currentCodeBlock = activeTab === 'ass' ? markdownAss : markdownSrt;

  const handleCopyCodeBlock = async () => {
    try {
      await navigator.clipboard.writeText(currentCodeBlock);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      console.error('Copy failed', err);
    }
  };

  const handleDownload = () => {
    const ext = activeTab === 'ass' ? 'ass' : 'srt';
    const mime = activeTab === 'ass' ? 'text/x-ssa;charset=utf-8' : 'text/plain;charset=utf-8';

    // UTF-8 with BOM (\uFEFF) ensures standard video players like VLC and PotPlayer
    // automatically detect Burmese Unicode without character rendering corruption.
    const blob = new Blob(['\uFEFF' + currentRaw], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `burmese_subtitles_${Date.now()}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-[#161b22] border border-[#30363d] rounded-2xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#30363d] flex items-center justify-between bg-[#0e1117]/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#2ea043]/15 border border-[#2ea043]/30 text-[#3fb950]">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Export Localized Subtitles (.SRT / .ASS)</h2>
              <p className="text-xs text-[#7d8590]">
                {blocks.length} subtitle blocks • UTF-8 Unicode formatted • Zero punctuation enforced
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-[#21262d] rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Format Selector Tabs */}
        <div className="px-6 pt-4 pb-2 flex items-center justify-between border-b border-[#30363d] bg-[#0e1117]/40">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('srt')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'srt'
                  ? 'bg-[#2ea043] text-white shadow-sm'
                  : 'text-[#7d8590] hover:text-[#e6edf3] bg-[#161b22] border border-[#30363d]'
              }`}
            >
              <span>.SRT SubRip Block</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('ass')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'ass'
                  ? 'bg-[#2ea043] text-white shadow-sm'
                  : 'text-[#7d8590] hover:text-[#e6edf3] bg-[#161b22] border border-[#30363d]'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-emerald-200" />
              <span>.ASS Advanced SubStation Block</span>
            </button>
          </div>

          <span className="text-[11px] text-[#7d8590] font-mono hidden sm:inline">
            {activeTab === 'ass' ? 'Preserves styles & override tags' : 'Universal standard timing format'}
          </span>
        </div>

        {/* Content: Code Block */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#3fb950]" />
              Standard ```{activeTab} Output Code Block
            </span>
            <span className="text-xs text-[#7d8590] font-mono">
              Ready for Aegisub, VLC, PotPlayer, MPV & Premiere Pro
            </span>
          </div>

          <div className="relative">
            <pre className="bg-[#0e1117] border border-[#30363d] rounded-xl p-4 text-xs font-mono text-[#e6edf3] overflow-x-auto max-h-[360px] leading-relaxed burmese-text select-all">
              {currentCodeBlock}
            </pre>

            <button
              type="button"
              onClick={handleCopyCodeBlock}
              className="absolute top-3 right-3 flex items-center gap-1.5 px-3 py-1.5 bg-[#21262d] hover:bg-[#2ea043] text-slate-200 hover:text-white rounded-lg text-xs font-medium transition-all shadow-md backdrop-blur-sm cursor-pointer border border-[#30363d]"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-300">Copied ```{activeTab}!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy ```{activeTab} Block</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-[#30363d] flex items-center justify-between bg-[#0e1117]/80">
          <span className="text-xs text-[#7d8590] hidden sm:inline">
            Encoded with UTF-8 BOM for universal Myanmar font compatibility
          </span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleCopyCodeBlock}
              className="px-4 py-2 text-xs font-semibold text-slate-200 bg-[#21262d] hover:bg-[#30363d] rounded-xl transition-all flex items-center gap-1.5 border border-[#30363d] cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? 'Copied!' : 'Copy ' + activeTab.toUpperCase() + ' Code'}</span>
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="px-5 py-2 text-xs font-semibold text-white bg-[#2ea043] hover:bg-[#238636] rounded-xl transition-all shadow-md shadow-[#2ea043]/30 flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .{activeTab.toUpperCase()} File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
