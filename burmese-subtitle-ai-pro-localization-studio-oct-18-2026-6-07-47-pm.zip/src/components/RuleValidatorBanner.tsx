import React from 'react';
import { ShieldCheck, AlertCircle, Wand2, CheckCircle2, AlertTriangle, Sparkles } from 'lucide-react';
import { SubtitleBlock } from '../types/subtitle';

interface RuleValidatorBannerProps {
  blocks: SubtitleBlock[];
  totalIssues: number;
  errorCount: number;
  warningCount: number;
  onAutoFixAll: () => void;
}

export const RuleValidatorBanner: React.FC<RuleValidatorBannerProps> = ({
  blocks,
  totalIssues,
  errorCount,
  warningCount,
  onAutoFixAll,
}) => {
  const translatedCount = blocks.filter((b) => b.burmeseText && b.burmeseText.trim()).length;
  if (translatedCount === 0) return null;

  const isAllValid = totalIssues === 0;

  return (
    <div
      className={`p-3.5 rounded-2xl border transition-all ${
        isAllValid
          ? 'bg-emerald-950/20 border-emerald-900/40 text-emerald-300'
          : errorCount > 0
          ? 'bg-rose-950/20 border-rose-900/40 text-rose-300'
          : 'bg-amber-950/20 border-amber-900/40 text-amber-300'
      }`}
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Status indicator */}
        <div className="flex items-center gap-3">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
              isAllValid
                ? 'bg-emerald-500/20 text-emerald-400'
                : errorCount > 0
                ? 'bg-rose-500/20 text-rose-400'
                : 'bg-amber-500/20 text-amber-400'
            }`}
          >
            {isAllValid ? (
              <ShieldCheck className="w-5 h-5" />
            ) : errorCount > 0 ? (
              <AlertCircle className="w-5 h-5" />
            ) : (
              <AlertTriangle className="w-5 h-5" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-white">
                {isAllValid
                  ? '100% Subtitle Formatting Compliance Verified'
                  : `${totalIssues} Formatting Violation${totalIssues > 1 ? 's' : ''} Detected`}
              </span>
              <span
                className={`text-[11px] px-2 py-0.5 rounded-full font-semibold ${
                  isAllValid
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {isAllValid ? 'Perfect SRT' : `${errorCount} Errors, ${warningCount} Warnings`}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {isAllValid
                ? 'Zero punctuation (no ။ ၊ ? !), natural spoken Burmese particles, varied endings, and 1:1 timestamps confirmed.'
                : 'Punctuation or literary particles need cleanup to match professional Burmese cinema rules.'}
            </p>
          </div>
        </div>

        {/* Quick Action Button */}
        {!isAllValid && (
          <button
            type="button"
            onClick={onAutoFixAll}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-rose-900/30 transition-all cursor-pointer"
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>Auto-Fix & Clean All Lines</span>
          </button>
        )}
      </div>
    </div>
  );
};
