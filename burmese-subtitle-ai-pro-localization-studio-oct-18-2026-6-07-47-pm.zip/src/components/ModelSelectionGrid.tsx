import React from 'react';
import { Cpu, CheckCircle } from 'lucide-react';
import { PREMIUM_AI_MODELS } from '../types/subtitle';

export interface ModelSelectionGridProps {
  selectedModel: string;
  onSelectModel: (modelId: string) => void;
  className?: string;
  showHeader?: boolean;
}

export const ModelSelectionGrid: React.FC<ModelSelectionGridProps> = ({
  selectedModel,
  onSelectModel,
  className = '',
  showHeader = true,
}) => {
  return (
    <div className={`space-y-3 p-4 rounded-xl bg-[#161b22] border border-[#30363d] shadow-md ${className}`}>
      {showHeader && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <label className="text-sm font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#3fb950]" />
              <span>မိမိစိတ်ကြိုက် Premium AI Model ကိုယ်တိုင်ရွေးချယ်ပါ</span>
            </label>
            <p className="text-xs text-[#7d8590] mt-0.5 leading-relaxed">
              ဝယ်ယူအသုံးပြုထားသော High-Performance AI Model ၇ ခုအနက် မိမိအသုံးပြုလိုသည့် Model အား တိုက်ရိုက်ရွေးချယ်နိုင်ပါသည်
            </p>
          </div>
          <span className="text-[10px] px-2.5 py-1 rounded-full bg-[#2ea043]/20 text-[#3fb950] font-mono font-bold border border-[#2ea043]/40 shrink-0 self-start sm:self-auto">
            လက်ရှိ Model: {selectedModel || 'gemini-3.8-flash'}
          </span>
        </div>
      )}

      {/* 7 AI Model Cards Grid with Burmese Titles & Descriptions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-1">
        {PREMIUM_AI_MODELS.map((model) => {
          const isSelected = selectedModel === model.id;
          return (
            <button
              key={model.id}
              type="button"
              onClick={() => onSelectModel(model.id)}
              className={`p-3 rounded-xl text-left transition-all border cursor-pointer relative group flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#2ea043]/15 border-[#2ea043] ring-1 ring-[#2ea043]/50 shadow-md shadow-[#2ea043]/10'
                  : 'bg-[#0e1117] border-[#30363d] hover:border-[#484f58] hover:bg-[#161b22]'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-base">{model.iconTag}</span>
                  <div>
                    <div className="font-bold text-xs text-white group-hover:text-emerald-300 transition-colors">
                      {model.name}
                    </div>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium border inline-block mt-0.5 ${model.badgeColor}`}>
                      {model.badge}
                    </span>
                  </div>
                </div>

                {/* Radio / Checkmark state */}
                <div className="shrink-0 pt-0.5">
                  {isSelected ? (
                    <div className="flex items-center gap-1 text-[11px] font-semibold text-[#3fb950]">
                      <CheckCircle className="w-4 h-4 fill-[#2ea043] text-[#0e1117]" />
                    </div>
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-[#484f58] group-hover:border-[#7d8590]" />
                  )}
                </div>
              </div>

              {/* Burmese Capability Description */}
              <div className="mt-2 text-[11px] leading-relaxed text-[#8b949e] group-hover:text-[#c9d1d9] transition-colors border-t border-[#21262d] pt-2">
                {model.burmeseSubtitle}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default ModelSelectionGrid;
