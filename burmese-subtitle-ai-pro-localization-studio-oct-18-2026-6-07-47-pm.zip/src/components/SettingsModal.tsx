import React, { useState } from 'react';
import { X, Plus, Trash2, CheckCircle, Sparkles, Cpu, Layers, FileText, ShieldCheck, ListOrdered, Globe } from 'lucide-react';
import { ProjectSettings, GenreType, PronounTone, CharacterNamePolicy, AIModelProfile, SubtitleFormat, SourceLanguage, AIModelId, PREMIUM_AI_MODELS } from '../types/subtitle';
import { ModelSelectionGrid } from './ModelSelectionGrid';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ProjectSettings;
  onSave: (updated: ProjectSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
}) => {
  const [current, setCurrent] = useState<ProjectSettings>(settings);
  const [newGlossarySource, setNewGlossarySource] = useState('');
  const [newGlossaryBurmese, setNewGlossaryBurmese] = useState('');
  const [newGlossaryNote, setNewGlossaryNote] = useState('');
  const [newCustomRule, setNewCustomRule] = useState('');

  if (!isOpen) return null;

  const handleAddGlossary = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGlossarySource.trim() || !newGlossaryBurmese.trim()) return;

    const newEntry = {
      id: Math.random().toString(36).substring(2, 9),
      source: newGlossarySource.trim(),
      burmese: newGlossaryBurmese.trim(),
      note: newGlossaryNote.trim() || undefined,
    };

    setCurrent((prev) => ({
      ...prev,
      customGlossary: [...prev.customGlossary, newEntry],
    }));

    setNewGlossarySource('');
    setNewGlossaryBurmese('');
    setNewGlossaryNote('');
  };

  const handleRemoveGlossary = (id: string) => {
    setCurrent((prev) => ({
      ...prev,
      customGlossary: prev.customGlossary.filter((g) => g.id !== id),
    }));
  };

  const handleAddCustomRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomRule.trim()) return;

    setCurrent((prev) => ({
      ...prev,
      customRules: [...(prev.customRules || []), newCustomRule.trim()],
    }));
    setNewCustomRule('');
  };

  const handleRemoveCustomRule = (index: number) => {
    setCurrent((prev) => ({
      ...prev,
      customRules: (prev.customRules || []).filter((_, i) => i !== index),
    }));
  };

  const handleSaveAndClose = () => {
    onSave(current);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Advanced Subtitle AI Configuration</h2>
              <p className="text-xs text-slate-400">AI Model profiles, .SRT / .ASS format controls, pronouns & custom rules</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm">
          {/* Manual AI Model Selection (မိမိစိတ်ကြိုက် Premium AI Model ကိုယ်တိုင်ရွေးချယ်ပါ) */}
          <ModelSelectionGrid
            selectedModel={current.modelProfile || 'gemini-3.8-flash'}
            onSelectModel={(modelId) =>
              setCurrent({
                ...current,
                selectedModel: modelId as AIModelId,
                modelProfile: modelId as AIModelProfile,
              })
            }
          />

          {/* Multilingual Translation Support (ဘာသာစကားစုံမှ ဘာသာပြန်ခြင်း) */}
          <div className="space-y-2 p-4 rounded-xl bg-[#161b22] border border-[#30363d]">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-[#3fb950]" />
                Multilingual Source Language (ဘာသာစကားစုံမှ ဘာသာပြန်ခြင်း)
              </label>
              <span className="text-[11px] text-[#3fb950] font-medium">Selected: {current.sourceLanguage || 'Auto-Detect'}</span>
            </div>
            <p className="text-xs text-[#7d8590]">
              ဂျပန်၊ ကိုရီးယား၊ အင်္ဂလိပ်၊ တရုတ်၊ ထိုင်းစသော ဘာသာစကားများမှ ယဉ်ကျေးမှုအသုံးအနှုန်းများနှင့် Honorifics များကို မြန်မာစကားပြောအဖြစ် သဘာဝကျကျ ပြောင်းလဲပေးပါသည်။
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 pt-1">
              {[
                { id: 'auto_detect', label: 'Auto-Detect (အလိုအလျောက်)', flag: '🌐' },
                { id: 'Japanese', label: 'Japanese (日本語 / ဂျပန်)', flag: '🇯🇵' },
                { id: 'Korean', label: 'Korean (한국어 / ကိုရီးယား)', flag: '🇰🇷' },
                { id: 'English', label: 'English (အင်္ဂလိပ်)', flag: '🇺🇸' },
                { id: 'Chinese', label: 'Chinese (中文 / တရုတ်)', flag: '🇨🇳' },
                { id: 'Thai', label: 'Thai (ภาษาไทย / ထိုင်း)', flag: '🇹🇭' },
                { id: 'Other', label: 'Other Foreign Languages', flag: '🌍' },
              ].map((lang) => (
                <button
                  key={lang.id}
                  type="button"
                  onClick={() => setCurrent({ ...current, sourceLanguage: lang.id as any })}
                  className={`p-2.5 rounded-xl text-xs font-medium text-left transition-all border cursor-pointer ${
                    (current.sourceLanguage || 'auto_detect') === lang.id
                      ? 'bg-[#2ea043]/20 border-[#2ea043] text-white shadow-sm ring-1 ring-[#2ea043]/30'
                      : 'bg-[#0e1117] border-[#30363d] text-[#7d8590] hover:text-[#e6edf3] hover:border-[#484f58]'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm">{lang.flag}</span>
                    <span className="font-semibold truncate">{lang.label}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Movie & Show Genres */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#3fb950]" />
                Movie & Show Genre (ရုပ်ရှင်နှင့် ရှိုးအမျိုးအစားများ)
              </label>
              <span className="text-[11px] text-[#3fb950] font-medium">Selected: {current.genre}</span>
            </div>
            <p className="text-xs text-[#7d8590]">
              ရွေးချယ်ထားသော ဇာတ်ကားအမျိုးအစားအပေါ် မူတည်ပြီး ဘာသာပြန်အသုံးအနှုန်းနှင့် စကားပြောဟန်ကို အထူးပြုပြောင်းလဲပေးပါသည်။
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 pt-1">
              {([
                'Dynamic (Auto-Detect)',
                'C Drama',
                'Kdrama',
                'Drama',
                'Action',
                'Comedy',
                'Romance',
                'Anime',
                'Animation',
                'Horror',
                'Thriller',
                'Crime',
                'Historical',
                'Adult',
                'Supernatural',
                'Variety Show',
                'Reality Show',
                'Singing Competition',
                'Talent Show',
              ] as GenreType[]).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setCurrent({ ...current, genre: g })}
                  className={`px-3 py-2 rounded-xl text-xs font-medium text-left transition-all border cursor-pointer ${
                    current.genre === g
                      ? 'bg-[#2ea043]/20 border-[#2ea043] text-white shadow-sm ring-1 ring-[#2ea043]/40'
                      : 'bg-[#161b22] border-[#30363d] text-[#7d8590] hover:text-[#e6edf3] hover:border-[#484f58]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{g}</span>
                    {g === 'Dynamic (Auto-Detect)' && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-[#2ea043]/30 text-[#3fb950] font-bold">Auto</span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Subtitle Translation & Formatting Constraints */}
          <div className="space-y-2.5 p-4 rounded-xl bg-[#161b22] border border-[#30363d]">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#3fb950]" />
              Formatting & Rule Constraints (စည်းမျဉ်းထိန်းချုပ်မှုများ)
            </label>

            <div className="space-y-2 pt-1">
              {/* Long Sentence Auto-Splitting */}
              <label className="flex items-center justify-between p-2.5 rounded-lg bg-[#0e1117] border border-[#30363d] cursor-pointer">
                <div>
                  <div className="text-xs font-semibold text-[#e6edf3]">
                    Long Sentence Auto-Splitting (စာကြောင်းရှည် ၂ ကြောင်း ခွဲထုတ်ခြင်း)
                  </div>
                  <div className="text-[11px] text-[#7d8590]">
                    စာတန်းရှည်လွန်းပါက အချိန်တူညီသော block အတွင်း ညီညွတ်သော ၂ ကြောင်း အလိုအလျောက်ခွဲပေးမည်
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={current.autoSplitLongLines}
                  onChange={(e) => setCurrent({ ...current, autoSplitLongLines: e.target.checked })}
                  className="w-4 h-4 accent-[#2ea043] rounded"
                />
              </label>

              {/* Two-Speaker Separation */}
              <label className="flex items-center justify-between p-2.5 rounded-lg bg-[#0e1117] border border-[#30363d] cursor-pointer">
                <div>
                  <div className="text-xs font-semibold text-[#e6edf3]">
                    Two-Speaker Separation (လူနှစ်ဦးစကားပြော သီးခြားခွဲထုတ်ခြင်း)
                  </div>
                  <div className="text-[11px] text-[#7d8590]">
                    ဇာတ်ကောင် ၂ ဦး တစ်ပြိုင်နက်ပြောပါက "- စာကြောင်း ၁ \n- စာကြောင်း ၂" ပုံစံဖြင့် ခွဲထုတ်ပေးမည်
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={current.twoSpeakerSeparation}
                  onChange={(e) => setCurrent({ ...current, twoSpeakerSeparation: e.target.checked })}
                  className="w-4 h-4 accent-[#2ea043] rounded"
                />
              </label>

              {/* Filter Interjections & Filler Sounds */}
              <label className="flex items-center justify-between p-2.5 rounded-lg bg-[#0e1117] border border-[#30363d] cursor-pointer">
                <div>
                  <div className="text-xs font-semibold text-[#e6edf3]">
                    Filter Interjections & Filler Sounds (အာမေဍိတ်အပိုသံများ ဖယ်ရှားခြင်း)
                  </div>
                  <div className="text-[11px] text-[#7d8590]">
                    အဟမ်း၊ ဟား၊ ဟေး၊ အား၊ um၊ uh စသော သဘာဝမကျသည့် အသံများကို သန့်စင်ဖယ်ထုတ်ပေးမည်
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={current.filterFillerSounds}
                  onChange={(e) => setCurrent({ ...current, filterFillerSounds: e.target.checked })}
                  className="w-4 h-4 accent-[#2ea043] rounded"
                />
              </label>
            </div>
          </div>

          {/* Subtitle Format Selector (.srt vs .ass) */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-[#3fb950]" />
              Target Subtitle Format (.srt / .ass)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setCurrent({ ...current, subtitleFormat: 'srt' })}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  current.subtitleFormat === 'srt'
                    ? 'border-[#2ea043] bg-[#2ea043]/15 text-white shadow-sm'
                    : 'border-[#30363d] bg-[#161b22] text-[#7d8590] hover:border-[#484f58]'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-[#e6edf3]">.SRT (SubRip)</span>
                  {current.subtitleFormat === 'srt' && <CheckCircle className="w-4 h-4 text-[#3fb950]" />}
                </div>
                <p className="text-xs text-[#7d8590]">
                  Exact index numbers and timestamps (00:00:00,000 --&gt; 00:00:00,000). Universal player support.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setCurrent({ ...current, subtitleFormat: 'ass' })}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  current.subtitleFormat === 'ass'
                    ? 'border-[#2ea043] bg-[#2ea043]/15 text-white shadow-sm'
                    : 'border-[#30363d] bg-[#161b22] text-[#7d8590] hover:border-[#484f58]'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-[#e6edf3]">.ASS (Advanced SubStation)</span>
                  {current.subtitleFormat === 'ass' && <CheckCircle className="w-4 h-4 text-[#3fb950]" />}
                </div>
                <p className="text-xs text-[#7d8590]">
                  Preserves [Script Info], [V4+ Styles], and inline override tags ({'{\\pos}'}, {'{\\fs}'}, {'\\N'}).
                </p>
              </button>
            </div>
          </div>

          {/* Pronouns & Tone Profiles */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Pronouns & Tone Profile (နာမ်စားသုံးစွဲပုံ မူဝါဒ)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setCurrent({ ...current, pronouns: 'ငါ/မင်း' })}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  current.pronouns === 'ငါ/မင်း'
                    ? 'border-indigo-500 bg-indigo-950/30 text-white'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-semibold text-xs text-white">ငါ / မင်း (Casual / Shonen)</div>
                <p className="text-[11px] text-slate-400 mt-0.5">Anime rivals, peers, action banter</p>
              </button>

              <button
                type="button"
                onClick={() => setCurrent({ ...current, pronouns: 'ကျုပ်/ခင်ဗျား' })}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  current.pronouns === 'ကျုပ်/ခင်ဗျား'
                    ? 'border-indigo-500 bg-indigo-950/30 text-white'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-semibold text-xs text-white">ကျုပ် / ခင်ဗျား (Formal / Polite)</div>
                <p className="text-[11px] text-slate-400 mt-0.5">Detectives, superiors, respectful dialogue</p>
              </button>

              <button
                type="button"
                onClick={() => setCurrent({ ...current, pronouns: 'ကိုယ်/နင်' })}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  current.pronouns === 'ကိုယ်/နင်'
                    ? 'border-indigo-500 bg-indigo-950/30 text-white'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-semibold text-xs text-white">ကိုယ် / နင် (Romantic / Close)</div>
                <p className="text-[11px] text-slate-400 mt-0.5">Lovers, close romantic bonds</p>
              </button>

              <button
                type="button"
                onClick={() => setCurrent({ ...current, pronouns: 'auto_contextual' })}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  current.pronouns === 'auto_contextual'
                    ? 'border-indigo-500 bg-indigo-950/30 text-white'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-semibold text-xs text-white">Auto / Contextual</div>
                <p className="text-[11px] text-slate-400 mt-0.5">Detects speaker dynamics automatically</p>
              </button>
            </div>
          </div>

          {/* Character Name Policy */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Character Name Policy (ဇာတ်ကောင်အမည် မူဝါဒ)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setCurrent({ ...current, characterPolicy: 'keep_english' })}
                className={`p-3 rounded-xl border text-left transition-all ${
                  current.characterPolicy === 'keep_english'
                    ? 'border-amber-500 bg-amber-500/10 text-white shadow-sm'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-200">Keep English</span>
                  {current.characterPolicy === 'keep_english' && (
                    <CheckCircle className="w-4 h-4 text-amber-400" />
                  )}
                </div>
                <p className="text-xs text-slate-400">
                  Keep English names intact (e.g. Gojo, Yuji, Naruto, Bruce).
                </p>
              </button>

              <button
                type="button"
                onClick={() => setCurrent({ ...current, characterPolicy: 'burmese_transliteration' })}
                className={`p-3 rounded-xl border text-left transition-all ${
                  current.characterPolicy === 'burmese_transliteration'
                    ? 'border-amber-500 bg-amber-500/10 text-white shadow-sm'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-200">Burmese Transliteration</span>
                  {current.characterPolicy === 'burmese_transliteration' && (
                    <CheckCircle className="w-4 h-4 text-amber-400" />
                  )}
                </div>
                <p className="text-xs text-slate-400">
                  Transliterate names to Burmese (e.g. ဂိုဂျို၊ ယူဂျီ၊ နာရူတို).
                </p>
              </button>
            </div>
          </div>

          {/* Strict Custom Rules Editor */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <ListOrdered className="w-4 h-4 text-indigo-400" />
                Custom Localization Rules (စိတ်ကြိုက် စည်းမျဉ်းများ)
              </label>
              <span className="text-xs text-slate-500">{(current.customRules || []).length} active rules</span>
            </div>

            {/* List */}
            {(current.customRules || []).length > 0 && (
              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {current.customRules.map((rule, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between px-3 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs"
                  >
                    <span className="text-slate-300">📌 {rule}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveCustomRule(idx)}
                      className="text-slate-500 hover:text-rose-400 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Add rule */}
            <form onSubmit={handleAddCustomRule} className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. Translate 'sensei' as 'ဆရာ', or use sarcastic tone for Character B"
                value={newCustomRule}
                onChange={(e) => setNewCustomRule(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                disabled={!newCustomRule.trim()}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white rounded-xl text-xs font-medium transition-colors"
              >
                Add Rule
              </button>
            </form>
          </div>

          {/* Custom Character / Glossary List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Character & Terms Glossary (အမည်နှင့် အသုံးအနှုန်းသတ်မှတ်ချက်)
              </label>
              <span className="text-xs text-slate-500">{current.customGlossary.length} terms defined</span>
            </div>

            {/* List */}
            {current.customGlossary.length > 0 && (
              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {current.customGlossary.map((entry) => (
                  <div
                    key={entry.id}
                    className="flex items-center justify-between px-3 py-2 bg-slate-950/80 border border-slate-800/80 rounded-xl text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-200">{entry.source}</span>
                      <span className="text-slate-500">→</span>
                      <span className="font-medium text-amber-300">{entry.burmese}</span>
                      {entry.note && (
                        <span className="text-slate-500 italic">({entry.note})</span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveGlossary(entry.id)}
                      className="text-slate-500 hover:text-rose-400 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Add term form */}
            <div className="p-3 bg-slate-950/50 border border-slate-800/80 rounded-xl space-y-2">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  type="text"
                  placeholder="Original (e.g. Megumi)"
                  value={newGlossarySource}
                  onChange={(e) => setNewGlossarySource(e.target.value)}
                  className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                />
                <input
                  type="text"
                  placeholder="Burmese (e.g. မဲဂူမီ)"
                  value={newGlossaryBurmese}
                  onChange={(e) => setNewGlossaryBurmese(e.target.value)}
                  className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                />
                <input
                  type="text"
                  placeholder="Note (optional)"
                  value={newGlossaryNote}
                  onChange={(e) => setNewGlossaryNote(e.target.value)}
                  className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>
              <button
                type="button"
                onClick={handleAddGlossary}
                disabled={!newGlossarySource.trim() || !newGlossaryBurmese.trim()}
                className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-300 hover:text-white rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add to Glossary
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-end gap-3 bg-slate-950/70">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSaveAndClose}
            className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all shadow-md shadow-indigo-600/30"
          >
            Apply Configuration
          </button>
        </div>
      </div>
    </div>
  );
};
