import { SubtitleBlock } from '../types/subtitle';

/**
 * Converts "00:01:23,450" or "00:01:23.450" string to milliseconds
 */
export function timecodeToMs(timecode: string): number {
  if (!timecode) return 0;
  const normalized = timecode.trim().replace('.', ',');
  const parts = normalized.split(':');
  if (parts.length < 3) return 0;

  const hours = parseInt(parts[0], 10) || 0;
  const minutes = parseInt(parts[1], 10) || 0;
  const [secondsStr, msStr] = parts[2].split(',');
  const seconds = parseInt(secondsStr, 10) || 0;
  const ms = parseInt((msStr || '0').padEnd(3, '0').slice(0, 3), 10) || 0;

  return hours * 3600000 + minutes * 60000 + seconds * 1000 + ms;
}

/**
 * Converts milliseconds to standard SRT timecode: "00:01:23,450"
 */
export function msToTimecode(ms: number): string {
  if (isNaN(ms) || ms < 0) ms = 0;
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  const remainderMs = Math.floor(ms % 1000);

  const pad = (n: number, z = 2) => String(n).padStart(z, '0');
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)},${pad(remainderMs, 3)}`;
}

/**
 * Parses raw SRT string content into SubtitleBlock array
 */
export function parseSrt(rawContent: string): SubtitleBlock[] {
  if (!rawContent || !rawContent.trim()) return [];

  // Normalize line endings
  const normalized = rawContent.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const rawBlocks = normalized.trim().split(/\n\s*\n/);
  const blocks: SubtitleBlock[] = [];

  let fallbackId = 1;

  for (const block of rawBlocks) {
    const lines = block.trim().split('\n');
    if (lines.length === 0) continue;

    let id = fallbackId;
    let timeLineIndex = 0;

    // Check if line 0 is a number index
    const firstLineAsNum = parseInt(lines[0].trim(), 10);
    if (!isNaN(firstLineAsNum) && lines[1] && lines[1].includes('-->')) {
      id = firstLineAsNum;
      timeLineIndex = 1;
    } else if (lines[0].includes('-->')) {
      timeLineIndex = 0;
    } else {
      // Not a valid SRT block
      continue;
    }

    const timeLine = lines[timeLineIndex];
    const timeMatch = timeLine.match(/(\d{2}:\d{2}:\d{2}[,\.]\d{1,3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,\.]\d{1,3})/);

    let startTime = '00:00:00,000';
    let endTime = '00:00:00,000';

    if (timeMatch) {
      startTime = timeMatch[1].replace('.', ',');
      endTime = timeMatch[2].replace('.', ',');
    }

    const textLines = lines.slice(timeLineIndex + 1);
    const sourceText = textLines.join('\n').trim();

    blocks.push({
      id,
      startTime,
      endTime,
      startMs: timecodeToMs(startTime),
      endMs: timecodeToMs(endTime),
      sourceText,
      burmeseText: '',
      status: 'pending',
    });

    fallbackId = id + 1;
  }

  return blocks;
}

/**
 * Exports blocks to standard .srt file string format
 * @param blocks SubtitleBlock[]
 * @param useBurmese boolean (if true, uses burmeseText, falling back to sourceText)
 */
export function generateSrtContent(blocks: SubtitleBlock[], useBurmese = true): string {
  return blocks
    .map((b) => {
      const text = useBurmese ? (b.burmeseText || b.sourceText) : b.sourceText;
      return `${b.id}\n${b.startTime} --> ${b.endTime}\n${text.trim()}`;
    })
    .join('\n\n') + '\n';
}

/**
 * Wraps generated SRT into a markdown code block ```srt ... ```
 */
export function formatAsSrtCodeBlock(blocks: SubtitleBlock[], useBurmese = true): string {
  const content = generateSrtContent(blocks, useBurmese);
  return `\`\`\`srt\n${content}\`\`\``;
}
