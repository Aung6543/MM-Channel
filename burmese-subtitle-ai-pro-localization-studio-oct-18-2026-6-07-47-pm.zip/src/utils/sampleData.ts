import { SubtitleBlock, SubtitleFormat, GenreType } from '../types/subtitle';
import { parseSrt } from './srtParser';
import { parseAss, DEFAULT_ASS_HEADERS } from './assParser';

// 1. Action .SRT (With 2-speaker split)
export const SAMPLE_ACTION_SRT = `1
00:01:10,500 --> 00:01:14,200
- (Captain Miller) [Radio static] Bravo Team, breach the south entrance right now!
- (Sergeant Vance) Negative sir! Heavy sniper fire on the perimeter!

2
00:01:14,800 --> 00:01:18,500
[Explosion in distance] If we don't extract the hostage within three minutes, the whole compound will be detonated!

3
00:01:19,000 --> 00:01:22,800
- (Vance) [Breathing heavily] Ah, I've spotted the detonator wired behind the steel door!
- (Miller) Cut the blue wire and secure the prisoner immediately!
`;

// 2. Drama .SRT (With 2-speaker split)
export const SAMPLE_DRAMA_SRT = `1
00:02:05,100 --> 00:02:09,300
- (Father) [Sighs] You walked away from this family ten years ago without looking back once!
- (Son) I had to leave to survive, because staying in this house was suffocating me!

2
00:02:09,800 --> 00:02:14,200
Do you really believe running away to the capital made you any happier or freed you from the guilt you still carry inside?

3
00:02:14,700 --> 00:02:18,500
- (Mother) [Weeping softly] Please, stop screaming at each other before you destroy what little love we have left!
- (Son) Ugh, I only came back to say goodbye for good.
`;

// 3. Comedy .SRT (With 2-speaker split)
export const SAMPLE_COMEDY_SRT = `1
00:03:12,000 --> 00:03:16,200
- (Bob) [Giggles] Did you seriously tell the landlord that our pet racoon was an emotional support cat?
- (Dave) Well, he purred when the landlord gave him cheese!

2
00:03:16,800 --> 00:03:21,500
He didn't purr, Dave! He stole the landlord's golden wristwatch and fled straight through the kitchen ventilation duct!

3
00:03:22,000 --> 00:03:26,000
- (Dave) [Coughing] Look at the bright side, at least we don't have to pay rent until he finds his watch!
- (Bob) You are genuinely an absolute lunatic!
`;

// 4. Romance .SRT (With 2-speaker split)
export const SAMPLE_ROMANCE_SRT = `1
00:04:15,000 --> 00:04:19,200
- (Leo) [Gentle breeze] I spent every single day wondering if you still remembered our promise under the rain.
- (Clara) How could I ever forget the only person who made me feel alive?

2
00:04:19,800 --> 00:04:24,500
Even if miles separated us and years went by, my heart never once stopped beating for you in every quiet moment of the night.

3
00:04:25,000 --> 00:04:29,000
- (Leo) Then please don't let go of my hand ever again.
- (Clara) [Tears falling] I promise, I'll stay right beside you forever.
`;

// 5. Horror / Thriller .SRT (With 2-speaker split)
export const SAMPLE_HORROR_THRILLER_SRT = `1
00:05:02,400 --> 00:05:06,800
- (Mark) [Floorboards creaking] Shh, turn off your flashlight! Someone is walking directly above us!
- (Elena) [Whispering] That's impossible, the attic door has been locked from the outside for fifty years!

2
00:05:07,300 --> 00:05:11,900
[Violent banging] Whatever is trapped behind those walls is not human, and it knows exactly where we are hiding right now!

3
00:05:12,400 --> 00:05:16,200
- (Elena) [Sobbing in terror] Run! The lock just shattered into pieces!
- (Mark) Keep moving toward the basement window, don't look back!
`;

// 6. Crime / Mystery .SRT (With 2-speaker split)
export const SAMPLE_CRIME_MYSTERY_SRT = `1
00:06:10,200 --> 00:06:14,600
- (Detective Cross) [Camera clicks] The victim's watch stopped at precisely 11:42 PM, but the security log was wiped clean at midnight.
- (Agent Reed) Which proves the killer had top-level administrative access to the entire security grid.

2
00:06:15,100 --> 00:06:19,800
Only three people in this entire corporation possessed the biometric clearance key to bypass the vault mainframe without triggering alarms.

3
00:06:20,300 --> 00:06:24,500
- (Detective Cross) Check the vice president's flight itinerary right now!
- (Agent Reed) [Typing fast] He already booked a private jet departure for Zurich thirty minutes ago!
`;

// 7. Historical / Period .SRT (With 2-speaker split)
export const SAMPLE_HISTORICAL_PERIOD_SRT = `1
00:07:05,000 --> 00:07:09,500
- (General Thant) [Horses galloping] Your Majesty, the rebel vanguard has crossed the southern river pass!
- (Prime Minister) We must dispatch the royal elephant battalion before dawn breaks upon the valley!

2
00:07:10,000 --> 00:07:15,000
If our royal army wavers before the western gates, three centuries of sovereign imperial honor will be reduced to dust and ashes!

3
00:07:15,500 --> 00:07:19,800
- (King) [Sword drawn] Sound the royal war drums across all seven bastions!
- (General Thant) To victory or death, my Lord King!
`;

// 8. Kdrama .SRT (With 2-speaker split)
export const SAMPLE_KDRAMA_SRT = `1
00:00:01,500 --> 00:00:05,200
- (Min-ho) Did you secretly meet Director Park at the hospital yesterday evening?
- (Ji-won) [Whispering] Yes, but he completely refused to hand over the medical audit records.

2
00:00:05,800 --> 00:00:10,500
If we don't present concrete evidence at the board hearing tomorrow morning, everything our team built will be completely destroyed!

3
00:00:11,000 --> 00:00:14,800
- (Min-ho) [Sighs] Don't give up yet! Oppa will protect you no matter what!
- (Ji-won) How can I stay calm when our company and our lives are on the line?
`;

// C Drama (Chinese Drama) .SRT (With 2-speaker split)
export const SAMPLE_CDRAMA_SRT = `1
00:01:05,200 --> 00:01:09,800
- (Gu Hai) [Horse neighs] Wei gege, the imperial guard has surrounded the mountain fortress!
- (Lu Wei) Let them come. Tonight we settle the debt of the fallen palace disciples!

2
00:01:10,300 --> 00:01:15,000
[Swords clashing] Master taught us never to draw our blades against the dynasty, but their cold betrayal has forced our hand!

3
00:01:15,500 --> 00:01:19,800
- (Princess Xiao) [Tears falling] Wei gege, please withdraw your sword before the grand preceptor arrives!
- (Lu Wei) Shimei, step aside. A warrior's honor cannot be traded for mercy.
`;

// 9. Anime .SRT (With 2-speaker split)
export const SAMPLE_ANIME_SRT = `1
00:00:01,200 --> 00:00:05,000
- (Sakura) [Crying] Naruto, don't rush in alone! His dark chakra is way too dangerous!
- (Naruto) I made a sacred promise to Sasuke... I won't back down now!

2
00:00:05,600 --> 00:00:10,200
Even if my body breaks into pieces, that's my ninja way, and a true ninja never abandons his comrades!

3
00:00:10,800 --> 00:00:14,600
- (Orochimaru) [Evil laughter] Foolish boy, your weak friendship cannot pierce my curse!
- (Naruto) [Rasengan surging] Take this! Giant Rasengan!
`;

// 10. Anime .ASS (With Tag preservation & 2-speaker split)
export const SAMPLE_ANIME_ASS = `[Script Info]
Title: Jujutsu & Ninja Battle Special
ScriptType: v4.00+
WrapStyle: 0
PlayResX: 1920
PlayResY: 1080

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Noto Sans Myanmar,56,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,3.5,1.5,2,30,30,35,1
Style: ShonenShout,Noto Sans Myanmar,64,&H0000FFFF,&H000000FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,4.5,2,2,30,30,35,1
Style: VillainThreat,Noto Sans Myanmar,58,&H001111EE,&H000000FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,4,2,2,30,30,35,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:01.20,0:00:04.80,Default,Gojo,0,0,0,,{\pos(960,950)}- (Gojo) Megumi, stay back!\N- (Megumi) [Grit teeth] I can handle this special grade curse alone!
Dialogue: 0,0:00:05.10,0:00:08.20,ShonenShout,Yuji,0,0,0,,{\fs68\c&H0055FF&}[Power surging] I can't just stand here and do nothing while my friends bleed!
Dialogue: 0,0:00:08.60,0:00:11.80,VillainThreat,Sukuna,0,0,0,,{\c&H0000EE&}Fools... you dare challenge the undisputed King of Curses?
Dialogue: 0,0:00:12.20,0:00:15.50,Default,Megumi,0,0,0,,{\pos(960,950)}- (Megumi) Divine Dog, attack!\N- (Gojo) Good job Megumi, leave the rest to your sensei!
Dialogue: 0,0:00:15.90,0:00:18.90,ShonenShout,Yuji,0,0,0,,{\fs64}Black Flash! Prepare yourself!
`;

// 11. Animation .SRT (With 2-speaker split)
export const SAMPLE_ANIMATION_SRT = `1
00:01:05,200 --> 00:01:09,500
- (Pip the Rabbit) [Flapping wings] Look above the cloud forest! The golden acorn tree is actually glowing!
- (Barnaby Bear) Don't fly too close Pip, the ancient squirrel guardians might spot you!

2
00:01:10,000 --> 00:01:14,600
Grandpa told us that whoever reaches the highest branch before sunset will receive one magical wish for the entire woodland!

3
00:01:15,100 --> 00:01:19,200
- (Pip) [Giggling] Catch me if you can, slowpoke!
- (Barnaby) [Panting heavily] Wait for me! Bears aren't built for high-speed parkour!
`;

// 12. Adult .SRT (With 2-speaker split)
export const SAMPLE_ADULT_SRT = `1
00:08:12,100 --> 00:08:16,500
- (Vincent) [Pouring whiskey] You knew coming up to my penthouse at 2:00 AM wasn't just about reviewing court documents.
- (Natalie) Don't flatter yourself Vincent, I came because you still owe me the truth.

2
00:08:17,000 --> 00:08:21,800
We both know the dangerous game we've been playing with fire, and once we cross this threshold there is no going back to playing innocent.

3
00:08:22,300 --> 00:08:26,500
- (Vincent) [Whispering close] Then stop talking and kiss me already.
- (Natalie) [Breathing softly] Lock the door first.
`;

// 13. Supernatural .SRT (With 2-speaker split)
export const SAMPLE_SUPERNATURAL_SRT = `1
00:09:15,300 --> 00:09:19,800
- (Father Gabriel) [Chanting latin] The salt circle is fracturing! The demonic entity has breached the altar!
- (Sister Katherine) [Holding crucifix] The holy water isn't burning its flesh anymore!

2
00:09:20,300 --> 00:09:25,200
[Demonic shriek] This is not an ordinary imp from the lower realms... this is an ancient archdemon summoned by blood sacrifice!

3
00:09:25,700 --> 00:09:29,800
- (Gabriel) Recite Psalm 91 with all your soul, Katherine!
- (Katherine) [Crying out] In the name of the Father and the Son, release this innocent soul!
`;

// 14. Variety Show .SRT (With 2-speaker split)
export const SAMPLE_VARIETY_SHOW_SRT = `1
00:10:02,000 --> 00:10:06,400
- (MC Jaesuk) [Audience cheering] Welcome back to the Spicy Noodle Challenge Round 3!
- (Haha) Jaesuk hyung, look at Jongkook's face right now, he's turning completely purple!

2
00:10:07,000 --> 00:10:11,500
[Whistle blows] If any member drinks even a single sip of iced milk before the five-minute buzzer sounds, the entire team is disqualified!

3
00:10:12,000 --> 00:10:16,200
- (Jongkook) [Coughing violently] Haha, if you steal my milk carton I will personally throw you in the pool!
- (Haha) [Screaming] Mercy! I was just holding the straw for you!
`;

// 15. Reality Show .SRT (With 2-speaker split)
export const SAMPLE_REALITY_SHOW_SRT = `1
00:11:10,200 --> 00:11:14,800
- (Chloe) [Drama sting] You told Marcus by the poolside that I was playing both him and Tyler for votes!
- (Amber) Because you were, Chloe! Everyone in this villa sees straight through your sweet little facade!

2
00:11:15,300 --> 00:11:20,200
Don't stand there playing the victim in front of the cameras when you literally swore on your mother's bracelet you would couple up with Tyler!

3
00:11:20,700 --> 00:11:25,000
- (Chloe) [Slamming wine glass] Pack your bags Amber, because at tomorrow's elimination ceremony you are going home!
- (Amber) We will see who the audience votes to keep tonight, darling!
`;

// 16. Singing Competition .SRT (With 2-speaker split)
export const SAMPLE_SINGING_COMPETITION_SRT = `1
00:12:05,100 --> 00:12:09,800
- (Judge Simon) [Audience roaring] That final high note in the bridge... it gave every single person in this auditorium chills!
- (Judge Nicole) You took a legendary Whitney Houston ballad and made it entirely your own masterpiece tonight!

2
00:12:10,300 --> 00:12:15,100
When you walked onto this stage twelve weeks ago with an acoustic guitar, nobody predicted you would emerge as the frontrunner of season ten.

3
00:12:15,600 --> 00:12:19,800
- (Contestant Maya) [Tears of joy] Thank you so much! My grandmother taught me this song before she passed away.
- (Judge Simon) Well Maya, she is definitely smiling down on you right now, you are going straight to the Grand Finale!
`;

// 17. Talent Show .SRT (With 2-speaker split)
export const SAMPLE_TALENT_SHOW_SRT = `1
00:13:01,000 --> 00:13:05,500
- (Host Terry) [Suspense drumroll] Ladies and gentlemen, the aerialist duo is now attempting the triple blindfold spin eighty feet in the air!
- (Judge Sofia) [Gasping] Oh my goodness, there isn't even a safety net beneath them!

2
00:13:06,000 --> 00:13:10,800
[Thunderous standing ovation] That was without a shadow of a doubt the most dangerous and electrifying acrobatic stunt ever performed on live television!

3
00:13:11,300 --> 00:13:15,600
- (Judge Howie) I don't even need to consult the other judges for this one!
- (Judge Sofia) [Hitting buzzer] GOLDEN BUZZER! You are going directly to the live shows in Hollywood!
`;

// Ambiguous Slang .SRT (back-compat)
export const SAMPLE_AMBIGUOUS_SRT = `1
00:00:05,000 --> 00:00:08,200
- (Alex) [Whispering] Are you really down for this heist tonight?
- (Sam) They said she already spilled the tea to the police!

2
00:00:08,800 --> 00:00:12,500
Shut up! If anyone overhears us talking near the squad car, you're going to get us all busted!
`;

export type AllPresetKey =
  | 'action_srt'
  | 'drama_srt'
  | 'comedy_srt'
  | 'romance_srt'
  | 'horror_thriller_srt'
  | 'crime_mystery_srt'
  | 'historical_period_srt'
  | 'kdrama_srt'
  | 'anime_srt'
  | 'anime_ass'
  | 'animation_srt'
  | 'adult_srt'
  | 'supernatural_srt'
  | 'variety_show_srt'
  | 'reality_show_srt'
  | 'singing_competition_srt'
  | 'talent_show_srt'
  | 'action'
  | 'kdrama'
  | 'romance'
  | 'ambiguous';

export function getSampleDataset(sampleKey: string): {
  format: SubtitleFormat;
  headers?: string;
  blocks: SubtitleBlock[];
  genre: GenreType;
} {
  switch (sampleKey) {
    case 'anime_ass': {
      const parsed = parseAss(SAMPLE_ANIME_ASS);
      return { format: 'ass', headers: parsed.headers, blocks: parsed.blocks, genre: 'Anime' };
    }
    case 'action_srt':
    case 'action':
      return { format: 'srt', blocks: parseSrt(SAMPLE_ACTION_SRT), genre: 'Action' };
    case 'drama_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_DRAMA_SRT), genre: 'Drama' };
    case 'comedy_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_COMEDY_SRT), genre: 'Comedy' };
    case 'romance_srt':
    case 'romance':
      return { format: 'srt', blocks: parseSrt(SAMPLE_ROMANCE_SRT), genre: 'Romance' };
    case 'horror_thriller_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_HORROR_THRILLER_SRT), genre: 'Horror' };
    case 'crime_mystery_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_CRIME_MYSTERY_SRT), genre: 'Crime' };
    case 'historical_period_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_HISTORICAL_PERIOD_SRT), genre: 'Historical' };
    case 'kdrama_srt':
    case 'kdrama':
      return { format: 'srt', blocks: parseSrt(SAMPLE_KDRAMA_SRT), genre: 'Kdrama' };
    case 'c_drama_srt':
    case 'c_drama':
      return { format: 'srt', blocks: parseSrt(SAMPLE_CDRAMA_SRT), genre: 'C Drama' };
    case 'anime_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_ANIME_SRT), genre: 'Anime' };
    case 'animation_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_ANIMATION_SRT), genre: 'Animation' };
    case 'adult_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_ADULT_SRT), genre: 'Adult' };
    case 'supernatural_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_SUPERNATURAL_SRT), genre: 'Supernatural' };
    case 'variety_show_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_VARIETY_SHOW_SRT), genre: 'Variety Show' };
    case 'reality_show_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_REALITY_SHOW_SRT), genre: 'Reality Show' };
    case 'singing_competition_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_SINGING_COMPETITION_SRT), genre: 'Singing Competition' };
    case 'talent_show_srt':
      return { format: 'srt', blocks: parseSrt(SAMPLE_TALENT_SHOW_SRT), genre: 'Talent Show' };
    case 'ambiguous':
    default:
      return { format: 'srt', blocks: parseSrt(SAMPLE_AMBIGUOUS_SRT), genre: 'Drama' };
  }
}

export function getSampleBlocks(sampleKey: string): SubtitleBlock[] {
  return getSampleDataset(sampleKey).blocks;
}
