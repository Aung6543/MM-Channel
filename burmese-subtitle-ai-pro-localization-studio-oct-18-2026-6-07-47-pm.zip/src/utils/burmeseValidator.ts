import { SubtitleBlock, ValidationIssue } from '../types/subtitle';

export const FORBIDDEN_PUNCTUATION = ['။', '၊', '?', '!'];

export const LITERARY_PARTICLES = [
  { word: 'သည်', spoken: 'တယ်', explanation: 'စာအရေးအသားသုံး "သည်" အစား စကားပြောသုံး "တယ်" ကိုသုံးပါ' },
  { word: '၏', spoken: 'ရဲ့', explanation: 'ပိုင်ဆိုင်မှုပြ "၏" အစား စကားပြောသုံး "ရဲ့" ကိုသုံးပါ' },
  { word: '၌', spoken: 'မှာ', explanation: 'နေရာပြ "၌" အစား စကားပြောသုံး "မှာ" ကိုသုံးပါ' },
  { word: '၎င်း', spoken: 'ဒီ / အဲဒီ', explanation: 'ရည်ညွှန်းပြ "၎င်း" အစား စကားပြောသုံး "ဒီ" သို့မဟုတ် "အဲဒီ" ကိုသုံးပါ' },
  { word: 'လျက်', spoken: 'ပြီးတော့ / ရင်း', explanation: 'ဆက်စပ်ပြ "လျက်" အစား စကားပြောသုံး "ပြီးတော့" သို့မဟုတ် "ရင်း" ကိုသုံးပါ' },
  { word: '၍', spoken: 'မို့လို့ / လို့', explanation: 'အကြောင်းပြ "၍" အစား စကားပြောသုံး "မို့လို့ / လို့" ကိုသုံးပါ' },
];

export const UNNECESSARY_FILLER_SOUNDS = [
  'အဟမ်း',
  'ဟား',
  'ဟေး',
  'အား',
  'အို',
  'ဟမ်',
  'အာ',
  'ဟင့်အင်း',
];

/**
 * Validates a single subtitle line against strict Burmese subtitle rules
 */
export function validateSubtitleLine(
  text: string,
  prevLineText?: string,
  maxCharsPerLine = 40,
  filterFillers = true
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  if (!text || !text.trim()) {
    return issues;
  }

  // 1. Zero Punctuation Rule: ။ ၊ ? !
  for (const char of FORBIDDEN_PUNCTUATION) {
    if (text.includes(char)) {
      let suggestion = 'ဖြုတ်ပစ်ပါ (Zero punctuation)';
      if (char === '၊') suggestion = 'ကော်မာအစား နေရာလွတ် (Space) ခြားပါ';
      if (char === '?') suggestion = 'မေးခွန်းသင်္ကေတအစား စကားပြောမေးခွန်းစကားလုံး (လား / လဲ / တုန်း / ဟင်) ထည့်ပါ';
      if (char === '။') suggestion = 'ပုဒ်မဖြုတ်ပါ (စာတန်းထိုးတွင် ပုဒ်မမထည့်ရ)';
      if (char === '!') suggestion = 'အာမေဍိတ်ဖြုတ်ပါ (အာမေဍိတ်စကားသံ ပေါ့/ကွာ ဖြင့်ဖော်ပြပါ)';

      issues.push({
        type: 'forbidden_punctuation',
        message: `စည်းမျဉ်းချိုးဖောက်မှု - တားမြစ်သင်္ကေတ '${char}' တွေ့ရှိသည်။ စာတန်းထိုးတွင် သင်္ကေတလုံးဝမသုံးရ။`,
        severity: 'error',
        charOrWord: char,
        suggestion,
      });
    }
  }

  // 2. Check literary particles
  for (const lit of LITERARY_PARTICLES) {
    if (text.includes(lit.word)) {
      issues.push({
        type: 'literary_particle',
        message: `စကားပြောဟန်မဟုတ်သော စာအသုံးအနှုန်း '${lit.word}' ပါဝင်နေသည်။`,
        severity: 'warning',
        charOrWord: lit.word,
        suggestion: `${lit.spoken} (${lit.explanation})`,
      });
    }
  }

  // 3. Consecutive 'တာ' ending rule
  const trimmed = text.trim();
  const prevTrimmed = prevLineText?.trim();
  if (trimmed.endsWith('တာ') && prevTrimmed && prevTrimmed.endsWith('တာ')) {
    issues.push({
      type: 'consecutive_ta',
      message: `စာကြောင်း ၂ ကြောင်း ဆက်တိုက် 'တာ' ဖြင့် အဆုံးသတ်ထားသည်။ စာတန်းထိုးအဆုံးသတ်ကို ပြောင်းလဲပေးပါ (တယ်၊ ပြီ၊ မယ်၊ နော်၊ ဗျာ၊ ရှင့်၊ ပေါ့)။`,
      severity: 'warning',
      charOrWord: 'တာ',
      suggestion: 'အဆုံးသတ်ကို တယ် / ပြီ / မယ် / နော် / ပေါ့ စသည်တို့ဖြင့် အလှည့်ကျ သုံးပေးပါ',
    });
  }

  // 4. Parentheses Cleaning Rule (...): Detect character names, speaker tags, or stage directions
  // Strip ASS override tags first to avoid misdetecting pos(x,y) within {...}
  const textWithoutAssTags = text.replace(/\{[^}]+\}/g, '');
  if (/\([^)]*\)/.test(textWithoutAssTags) || /（[^）]*）/.test(textWithoutAssTags)) {
    issues.push({
      type: 'parentheses_detected',
      message: `စည်းမျဉ်းချိုးဖောက်မှု - စာတန်းထိုးတွင် နာမည် သို့မဟုတ် ညွှန်ကြားချက်ကွင်းစကွင်းပိတ် (...) ပါဝင်နေသည်။ အလိုအလျောက်ဖျက်ပေးပါ (Parentheses cleaning)။`,
      severity: 'error',
      suggestion: 'ဇာတ်ကောင်နာမည်/ညွှန်ကြားချက် ကွင်းစကွင်းပိတ် (...) ကို အော်တိုဖျက်ပေးပါ',
    });
  }

  // 5. Brackets Cleaning Rule [...]: Detect sound effects, vocal descriptions, or stage actions
  if (/\[[^\]]*\]/.test(textWithoutAssTags) || /［[^］]*］/.test(textWithoutAssTags)) {
    issues.push({
      type: 'brackets_detected',
      message: `စည်းမျဉ်းချိုးဖောက်မှု - အသံဖော်ပြချက်/စတိတ်လှုပ်ရှားမှု ကွင်းစကွင်းပိတ် [...] ပါဝင်နေသည်။ စာတန်းထိုးတွင် အသံဖော်ပြချက်များ အလိုအလျောက်ဖျက်ရပါမည် (Brackets cleaning)။`,
      severity: 'error',
      suggestion: 'အသံဖော်ပြချက် ကွင်းစကွင်းပိတ် [...] ကို အော်တိုဖျက်ပေးပါ',
    });
  }

  // 6. Check for unnecessary vocal filler sounds
  if (filterFillers) {
    for (const filler of UNNECESSARY_FILLER_SOUNDS) {
      // Check as standalone word or token
      const regex = new RegExp(`(^|\\s)${filler}(\\s|$)`);
      if (regex.test(text)) {
        issues.push({
          type: 'unnecessary_filler',
          message: `မလိုအပ်သော အာမေဍိတ်/အသံထွက်ဆူညံသံ '${filler}' ပါဝင်နေသည်။ စာတန်းထိုးကို သန့်ရှင်းစေရန် ဖြုတ်ပစ်ပါ (Clean dialogue filtering)။`,
          severity: 'warning',
          charOrWord: filler,
          suggestion: 'ဖြုတ်ပစ်ပါ',
        });
      }
    }
  }

  // 7. Line length constraint check (Auto-split recommendation)
  const lines = text.split('\n');
  for (const l of lines) {
    // Strip ASS override tags when calculating visible character length
    const visibleLine = l.replace(/\{[^}]+\}/g, '').trim();
    if (visibleLine.length > maxCharsPerLine) {
      issues.push({
        type: 'line_too_long',
        message: `စာကြောင်းအရှည် (${visibleLine.length} စာလုံး) သည် ဖတ်ရှုရန်အကောင်းဆုံး ကန့်သတ်ချက် (${maxCharsPerLine} စာလုံး) ထက် ကျော်လွန်နေသည်။ စာကြောင်း ၂ ကြောင်းခွဲပေးပါ (Auto-split)။`,
        severity: 'warning',
        suggestion: 'စာကြောင်း ၂ ကြောင်း ခွဲပေးပါ',
      });
      break;
    }
  }

  return issues;
}

/**
 * Validates the entire block list
 */
export function validateAllBlocks(
  blocks: SubtitleBlock[],
  maxCharsPerLine = 40,
  filterFillers = true
): {
  totalIssues: number;
  errorCount: number;
  warningCount: number;
  blocksWithIssues: number;
} {
  let errorCount = 0;
  let warningCount = 0;
  let blocksWithIssues = 0;

  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i];
    const prevText = i > 0 ? blocks[i - 1].burmeseText : undefined;
    const issues = validateSubtitleLine(block.burmeseText, prevText, maxCharsPerLine, filterFillers);
    block.issues = issues;

    // Detect if two-speaker or long line
    const text = block.burmeseText || block.sourceText;
    block.isTwoSpeaker = text.includes('\n-') || text.startsWith('-') || /^[A-Z][a-z]+:.*[A-Z][a-z]+:/s.test(text);
    const visibleChars = (block.burmeseText || block.sourceText).replace(/\{[^}]+\}/g, '').trim();
    block.charCount = visibleChars.length;
    const durationSec = Math.max(0.5, (block.endMs - block.startMs) / 1000);
    block.readingCps = Math.round((visibleChars.length / durationSec) * 10) / 10;
    block.isTooLong = visibleChars.length > maxCharsPerLine && !text.includes('\n');

    if (issues.length > 0) {
      blocksWithIssues++;
      for (const iss of issues) {
        if (iss.severity === 'error') errorCount++;
        else warningCount++;
      }
    }
  }

  return {
    totalIssues: errorCount + warningCount,
    errorCount,
    warningCount,
    blocksWithIssues,
  };
}

/**
 * Intelligently splits a long Burmese subtitle line into 2 balanced lines
 * using natural spoken grammatical boundaries
 */
export function splitLongBurmeseLine(text: string): string {
  if (!text || text.includes('\n')) return text;

  // Preserve leading ASS tags
  let tags = '';
  let cleanText = text;
  const tagMatch = text.match(/^(\{[^}]+\})+/);
  if (tagMatch) {
    tags = tagMatch[0];
    cleanText = text.slice(tags.length).trim();
  }

  const mid = Math.floor(cleanText.length / 2);
  const boundaryTokens = ['ပြီးတော့', 'ဒါပေမဲ့', 'မို့လို့', 'ကြောင့်', 'ပေမယ့်', 'တဲ့အခါ', 'ရင်', 'လို့', 'မှ', 'ပြီး'];

  // Look for boundary tokens near the middle (+/- 15 characters)
  let bestSplitIndex = -1;
  let minDistance = 999;

  for (const token of boundaryTokens) {
    let searchPos = 0;
    while (true) {
      const idx = cleanText.indexOf(token, searchPos);
      if (idx === -1) break;

      const splitPoint = idx + token.length;
      const distance = Math.abs(splitPoint - mid);
      if (distance < minDistance && distance < cleanText.length * 0.35) {
        minDistance = distance;
        bestSplitIndex = splitPoint;
      }
      searchPos = idx + 1;
    }
  }

  // Fallback to nearest space near middle
  if (bestSplitIndex === -1) {
    let nearestSpace = -1;
    let spaceDist = 999;
    for (let i = 0; i < cleanText.length; i++) {
      if (cleanText[i] === ' ') {
        const d = Math.abs(i - mid);
        if (d < spaceDist) {
          spaceDist = d;
          nearestSpace = i;
        }
      }
    }
    if (nearestSpace !== -1 && spaceDist < cleanText.length * 0.4) {
      bestSplitIndex = nearestSpace;
    } else {
      // Split at midpoint
      bestSplitIndex = mid;
    }
  }

  const line1 = cleanText.substring(0, bestSplitIndex).trim();
  const line2 = cleanText.substring(bestSplitIndex).trim();

  return `${tags}${line1}\n${line2}`;
}

/**
 * Automatically cleans and sanitizes a Burmese subtitle line
 * - Parentheses Cleaning (...): Removes character names, speaker tags, or stage directions
 * - Brackets Cleaning [...]: Removes sound effects, vocal descriptions, or stage actions
 * - No Interjections / Filler Sounds: Filters out unnecessary vocal noises (အဟမ်း, ဟား, ဟေး, အား)
 * - Zero Punctuation: Strips ။, !, and ? (appends question particles if needed)
 * - Replaces commas with spaces
 * - Replaces literary words with spoken conversational Burmese
 * - Preserves ASS tags like {\pos(x,y)} intact
 */
export function autoCleanSubtitleText(text: string, filterFillers = true): string {
  if (!text) return '';

  // 1. Mask ASS override tags like {\pos(960,950)\c&H00FFFF&} so their parentheses are protected
  const assTags: string[] = [];
  let cleanText = text.replace(/\{[^}]+\}/g, (match) => {
    assTags.push(match);
    return `__ASS_TAG_${assTags.length - 1}__`;
  });

  // 2. Brackets Cleaning [...]: Remove sound effects, vocal descriptions, stage actions
  cleanText = cleanText
    .replace(/\[[^\]]*\]/g, ' ')
    .replace(/［[^］]*］/g, ' ');

  // 3. Parentheses Cleaning (...): Remove character names, speaker tags, stage directions
  cleanText = cleanText
    .replace(/\([^)]*\)/g, ' ')
    .replace(/（[^）]*）/g, ' ');

  // 4. Replace commas with a space
  cleanText = cleanText.replace(/[,၊]/g, ' ');

  // 5. Zero Punctuation - If ends with question mark, check if it already has question particles (လား/လဲ/တုန်း/ဟင်)
  if (cleanText.includes('?')) {
    const hasQuestionParticle = /(လား|လဲ|တုန်း|ဟင်|ပါလိမ့်|ရမှာလဲ|ရတာလဲ)/.test(cleanText);
    if (!hasQuestionParticle && cleanText.trim().endsWith('?')) {
      cleanText = cleanText.replace(/\?+/g, ' လား');
    } else {
      cleanText = cleanText.replace(/\?+/g, '');
    }
  }

  // 6. Remove ။ and !
  cleanText = cleanText.replace(/[။!]/g, '');

  // 7. Replace isolated single period but keep "..."
  cleanText = cleanText.replace(/([^.])\.([^.])/g, '$1 $2');
  cleanText = cleanText.replace(/([^.])\.$/g, '$1');

  // 8. Replace literary words with spoken equivalents
  for (const lit of LITERARY_PARTICLES) {
    if (lit.word === 'သည်' || lit.word === '၏' || lit.word === '၌' || lit.word === '၎င်း' || lit.word === 'လျက်' || lit.word === '၍') {
      const regex = new RegExp(`(^|\\s)${lit.word}(\\s|$)`, 'g');
      cleanText = cleanText.replace(regex, `$1${lit.spoken}$2`);
    }
  }

  // 9. Filter unnecessary filler vocal sounds (No interjections / filler sounds)
  if (filterFillers) {
    for (const filler of UNNECESSARY_FILLER_SOUNDS) {
      const regex = new RegExp(`(^|\\s)${filler}(\\s|$)`, 'g');
      cleanText = cleanText.replace(regex, ' ');
    }
    // Also remove common English/romanized vocal fillers if present
    const romanizedFillers = ['ugh', 'um', 'uh', 'ah', 'er', 'hmm'];
    for (const filler of romanizedFillers) {
      const regex = new RegExp(`(^|\\s)${filler}(\\s|$)`, 'gi');
      cleanText = cleanText.replace(regex, ' ');
    }
  }

  // 10. Restore ASS override tags
  let restored = cleanText.replace(/__ASS_TAG_(\d+)__/g, (_, idx) => assTags[parseInt(idx, 10)] || '');

  // 11. Normalize duplicate spaces while preserving newlines
  const lines = restored.split('\n');
  const normalizedLines = lines.map((l) => l.replace(/[ \t]+/g, ' ').trim()).filter((l) => l.length > 0);

  return normalizedLines.join('\n');
}

/**
 * Pre-cleans dialogue text in source subtitles by stripping (Names) and [Sound Effects]
 */
export function cleanSourceDialogue(text: string): string {
  if (!text) return '';

  const assTags: string[] = [];
  let masked = text.replace(/\{[^}]+\}/g, (match) => {
    assTags.push(match);
    return `__ASS_TAG_${assTags.length - 1}__`;
  });

  // Strip brackets [...] and ［...］
  masked = masked.replace(/\[[^\]]*\]/g, ' ').replace(/［[^］]*］/g, ' ');

  // Strip parentheses (...) and （...）
  masked = masked.replace(/\([^)]*\)/g, ' ').replace(/（[^）]*）/g, ' ');

  // Strip filler vocal sounds
  const englishFillers = ['ugh', 'um', 'uh', 'ah', 'er', 'hmm'];
  for (const filler of englishFillers) {
    masked = masked.replace(new RegExp(`(^|\\s)${filler}(\\s|,|$)`, 'gi'), ' ');
  }

  // Restore ASS tags
  const restored = masked.replace(/__ASS_TAG_(\d+)__/g, (_, idx) => assTags[parseInt(idx, 10)] || '');
  const lines = restored.split('\n').map((l) => l.replace(/[ \t]+/g, ' ').trim()).filter(Boolean);
  return lines.join('\n');
}
