import React, { useState, useEffect, useRef } from 'react';
import {
  Upload,
  Play,
  Sparkles,
  Download,
  FileText,
  Wand2,
  Trash2,
  RefreshCw,
  Plus,
  Tv,
  Edit3,
  Layers,
  ChevronRight,
  ShieldCheck,
  Film,
  AlertCircle,
  AlertTriangle,
  Clock,
  RotateCcw,
  EyeOff,
  Eye,
  Square,
  ChevronDown,
  ChevronUp,
  Cpu
} from 'lucide-react';

import { SubtitleBlock, ProjectSettings, CharacterNamePolicy, DetectedAmbiguity, SubtitleFormat, AIModelProfile, AIModelId, SourceLanguage, PronounTone, GenreType, PresetKey } from './types/subtitle';
import { parseSrt, generateSrtContent } from './utils/srtParser';
import { parseAss, generateAssContent, isAssContent, DEFAULT_ASS_HEADERS } from './utils/assParser';
import { validateAllBlocks, autoCleanSubtitleText } from './utils/burmeseValidator';
import { getSampleDataset, getSampleBlocks } from './utils/sampleData';

import { Navbar } from './components/Navbar';
import { SubtitleBlockRow } from './components/SubtitleBlockRow';
import { SubtitlePlayerPreview } from './components/SubtitlePlayerPreview';
import { RuleValidatorBanner } from './components/RuleValidatorBanner';
import { SettingsModal } from './components/SettingsModal';
import { RulesGuideModal } from './components/RulesGuideModal';
import { ExportModal } from './components/ExportModal';
import { PolicyPromptModal } from './components/PolicyPromptModal';
import { AiClarificationPanel } from './components/AiClarificationPanel';
import { AiChatDrawer } from './components/AiChatDrawer';

export default function App() {
  // Initial state loaded with the Jujutsu & Ninja .ASS sample with override tags
  const [blocks, setBlocks] = useState<SubtitleBlock[]>(() => {
    const initial = getSampleDataset('anime_ass');
    return initial.blocks;
  });

  const [activeSample, setActiveSample] = useState<PresetKey | null>('anime_ass');
  const [currentTimeMs, setCurrentTimeMs] = useState<number>(0);
  const [viewMode, setViewMode] = useState<'split' | 'editor' | 'player'>('split');

  // Strict Display Control (ဘာသာပြန်ပြီးမှ ပေါ်လာစေရန် စည်းမျဉ်း)
  const [hasCompletedTranslation, setHasCompletedTranslation] = useState<boolean>(false);

  // Display Control Rule: All translated subtitle blocks remain collapsed initially
  const [revealedBlockIds, setRevealedBlockIds] = useState<Set<number>>(new Set());

  const handleToggleReveal = (id: number) => {
    setRevealedBlockIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleRevealAll = () => {
    setRevealedBlockIds(new Set(blocks.map((b) => b.id)));
  };

  const handleHideAll = () => {
    setRevealedBlockIds(new Set());
  };

  // Advanced Localization Project Settings
  const [settings, setSettings] = useState<ProjectSettings>({
    modelProfile: 'gemini-3.8-flash',
    selectedModel: 'gemini-3.8-flash',
    sourceLanguage: 'auto_detect',
    subtitleFormat: 'ass',
    characterPolicy: 'burmese_transliteration',
    genre: 'Dynamic (Auto-Detect)',
    pronouns: 'auto_contextual',
    formality: 'casual',
    autoSplitLongLines: true,
    twoSpeakerSeparation: true,
    filterFillerSounds: true,
    maxCharsPerLine: 38,
    customGlossary: [
      { id: '1', source: 'Megumi', burmese: 'မဲဂူမီ', note: 'အဓိကဇာတ်ကောင်' },
      { id: '2', source: 'Yuji', burmese: 'ယူဂျီ', note: 'အဓိကဇာတ်ကောင်' },
      { id: '3', source: 'Gojo', burmese: 'ဂိုဂျို', note: 'ဆရာ' },
      { id: '4', source: 'Sukuna', burmese: 'ဆူကူနာ', note: 'ကျိန်စာဘုရင်' },
    ],
    customRules: [
      'Preserve all anime battle scream intensity in natural spoken Burmese',
      'Keep Japanese cursed technique names recognizable',
      'Uphold strict zero punctuation and varied endings throughout',
    ],
    additionalNotes: 'Supernatural anime battle scene with styled dialogue and positional override tags.',
    assHeaders: DEFAULT_ASS_HEADERS,
  });

  const [hasConfirmedPolicy, setHasConfirmedPolicy] = useState(true);
  const [isTranslating, setIsTranslating] = useState(false);
  const [translationProgress, setTranslationProgress] = useState({ current: 0, total: 0 });
  const [feedbackNote, setFeedbackNote] = useState<string | null>(null);
  const [detectedAmbiguities, setDetectedAmbiguities] = useState<DetectedAmbiguity[]>([]);
  const [rateLimitCountdown, setRateLimitCountdown] = useState<number | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Real-Time Stop Translation Control
  const stopRequestedRef = useRef<boolean>(false);
  const abortControllerRef = useRef<AbortController | null>(null);
  const [translationStoppedNotice, setTranslationStoppedNotice] = useState<string | null>(null);

  const handleStopTranslation = () => {
    stopRequestedRef.current = true;
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsTranslating(false);
    setHasCompletedTranslation(true);
    setTranslationStoppedNotice('⏹️ ဘာသာပြန်ခြင်းကို ရပ်တန့်ခဲ့ပါသည်။ ယခုအထိ ဘာသာပြန်ပြီးသမျှ စာကြောင်းများကို အောင်မြင်စွာ သိမ်းဆည်းထားပြီး ဖြစ်ပါသည်။ (Translation stopped. Progress saved up to this point.)');
  };

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isPolicyPromptOpen, setIsPolicyPromptOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [rawPasteOpen, setRawPasteOpen] = useState(false);
  const [rawPasteText, setRawPasteText] = useState('');

  // Handle automatic countdown timer for 429 rate limit cooldown
  useEffect(() => {
    if (rateLimitCountdown === null) return;
    if (rateLimitCountdown <= 0) {
      setRateLimitCountdown(null);
      setErrorMessage(null);
      handleStartTranslate();
      return;
    }

    const timer = setTimeout(() => {
      setRateLimitCountdown((prev) => (prev !== null ? prev - 1 : null));
    }, 1000);

    return () => clearTimeout(timer);
  }, [rateLimitCountdown]);

  // Re-run validation whenever blocks change
  useEffect(() => {
    validateAllBlocks(blocks);
  }, [blocks]);

  // Compute validation stats
  const validationStats = validateAllBlocks(blocks);

  // Switch sample dataset
  const handleSelectSample = (sampleKey: PresetKey) => {
    setActiveSample(sampleKey);
    const dataset = getSampleDataset(sampleKey);
    setBlocks(dataset.blocks);
    setCurrentTimeMs(0);
    setDetectedAmbiguities([]);
    setFeedbackNote(null);
    setRevealedBlockIds(new Set()); // Keep new sample collapsed per display rule
    setHasCompletedTranslation(false); // Strict Display Control: hidden until translated

    const targetGenre = dataset.genre || 'Dynamic (Auto-Detect)';
    const targetFormat = dataset.format || 'srt';

    // Natural default pronouns based on genre
    let defaultPronouns: PronounTone = 'auto_contextual';
    if (targetGenre === 'Anime') defaultPronouns = 'ငါ/မင်း';
    else if (targetGenre === 'Romance') defaultPronouns = 'ကိုယ်/နင်';
    else if (targetGenre === 'Historical') defaultPronouns = 'ကျုပ်/ခင်ဗျား';
    else if (targetGenre === 'Action') defaultPronouns = 'ကျုပ်/ခင်ဗျား';

    // Character name transliteration vs english
    const charPolicy: CharacterNamePolicy =
      targetGenre === 'Anime' || targetGenre === 'Kdrama' || targetGenre === 'Historical'
        ? 'burmese_transliteration'
        : 'keep_english';

    // Universal 2-speaker separation enabled across all 17 presets
    setSettings((prev) => ({
      ...prev,
      subtitleFormat: targetFormat,
      genre: targetGenre,
      pronouns: defaultPronouns,
      characterPolicy: charPolicy,
      twoSpeakerSeparation: true, // Universal 2-speaker split on all presets
      autoSplitLongLines: true,
      filterFillerSounds: true,
      assHeaders: dataset.headers || (targetFormat === 'ass' ? DEFAULT_ASS_HEADERS : prev.assHeaders),
    }));
  };

  // Upload custom SRT or ASS file
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileName = file.name.toLowerCase();
    const isAssFile = fileName.endsWith('.ass') || fileName.endsWith('.ssa');

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        if (isAssFile || isAssContent(content)) {
          const parsed = parseAss(content);
          if (parsed.blocks.length > 0) {
            setBlocks(parsed.blocks);
            setSettings((s) => ({ ...s, subtitleFormat: 'ass', assHeaders: parsed.headers }));
            setCurrentTimeMs(0);
            setDetectedAmbiguities([]);
            setFeedbackNote(null);
            setRevealedBlockIds(new Set());
            setHasCompletedTranslation(false);
            setIsPolicyPromptOpen(true);
          }
        } else {
          const parsed = parseSrt(content);
          if (parsed.length > 0) {
            setBlocks(parsed);
            setSettings((s) => ({ ...s, subtitleFormat: 'srt' }));
            setCurrentTimeMs(0);
            setDetectedAmbiguities([]);
            setFeedbackNote(null);
            setRevealedBlockIds(new Set());
            setHasCompletedTranslation(false);
            setIsPolicyPromptOpen(true);
          }
        }
      }
    };
    reader.readAsText(file);
  };

  // Paste raw SRT or ASS
  const handleApplyRawPaste = () => {
    if (!rawPasteText.trim()) return;

    if (isAssContent(rawPasteText)) {
      const parsed = parseAss(rawPasteText);
      if (parsed.blocks.length > 0) {
        setBlocks(parsed.blocks);
        setSettings((s) => ({ ...s, subtitleFormat: 'ass', assHeaders: parsed.headers }));
        setCurrentTimeMs(0);
        setDetectedAmbiguities([]);
        setRevealedBlockIds(new Set());
        setHasCompletedTranslation(false);
        setRawPasteOpen(false);
        setRawPasteText('');
        setIsPolicyPromptOpen(true);
      }
    } else {
      const parsed = parseSrt(rawPasteText);
      if (parsed.length > 0) {
        setBlocks(parsed);
        setSettings((s) => ({ ...s, subtitleFormat: 'srt' }));
        setCurrentTimeMs(0);
        setDetectedAmbiguities([]);
        setRevealedBlockIds(new Set());
        setHasCompletedTranslation(false);
        setRawPasteOpen(false);
        setRawPasteText('');
        setIsPolicyPromptOpen(true);
      }
    }
  };

  // Update text of a block
  const handleUpdateBlockText = (id: number, newBurmese: string) => {
    setBlocks((prev) =>
      prev.map((b) => (b.id === id ? { ...b, burmeseText: newBurmese, status: 'edited' } : b))
    );
  };

  // Auto fix all lines with illegal punctuation or literary particles
  const handleAutoFixAll = () => {
    setBlocks((prev) =>
      prev.map((b) => {
        if (!b.burmeseText) return b;
        const cleaned = autoCleanSubtitleText(b.burmeseText);
        return { ...b, burmeseText: cleaned };
      })
    );
  };

  // Translate all subtitle lines with Gemini API
  const handleStartTranslate = async () => {
    if (blocks.length === 0) return;

    if (!hasConfirmedPolicy) {
      setIsPolicyPromptOpen(true);
      return;
    }

    setErrorMessage(null);
    setRateLimitCountdown(null);
    setTranslationStoppedNotice(null);
    setIsTranslating(true);
    setTranslationProgress({ current: 0, total: blocks.length });

    stopRequestedRef.current = false;
    abortControllerRef.current = new AbortController();

    try {
      // Batch size of 10 lines ensures low latency, instant UI progress, and prevents response truncation
      const BATCH_SIZE = 10;
      const updatedBlocks = [...blocks];
      const allAmbiguities: DetectedAmbiguity[] = [];

      for (let i = 0; i < blocks.length; i += BATCH_SIZE) {
        if (stopRequestedRef.current) {
          break;
        }

        const chunk = blocks.slice(i, i + BATCH_SIZE);
        setTranslationProgress({ current: i + 1, total: blocks.length });

        let res: Response | null = null;
        for (let attempt = 0; attempt < 3; attempt++) {
          if (stopRequestedRef.current) break;
          try {
            res = await fetch('/api/translate-subtitles', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              credentials: 'include',
              signal: abortControllerRef.current?.signal,
              body: JSON.stringify({
                blocks: chunk,
                subtitleFormat: settings.subtitleFormat,
                modelProfile: settings.modelProfile,
                selectedModel: settings.selectedModel,
                sourceLanguage: settings.sourceLanguage,
                genre: settings.genre,
                characterPolicy: settings.characterPolicy,
                pronouns: settings.pronouns,
                formality: settings.formality,
                customGlossary: settings.customGlossary,
                customRules: settings.customRules,
                additionalNotes: settings.additionalNotes,
              }),
            });
            if (res && (res.ok || res.status === 429)) {
              break;
            }
          } catch (fetchErr: any) {
            if (fetchErr.name === 'AbortError' || stopRequestedRef.current) {
              console.log('Translation aborted by user.');
              break;
            }
            if (attempt < 2) {
              // Wait with exponential backoff (800ms, 1600ms) and retry
              await new Promise((resolve) => setTimeout(resolve, 800 * (attempt + 1)));
              continue;
            }
            throw fetchErr;
          }
        }

        if (stopRequestedRef.current || !res) {
          break;
        }

        // Safely inspect response content-type to avoid '<!doctype html>' JSON parse crashes
        let data: any = null;
        const contentType = res.headers.get('content-type') || '';

        if (contentType.includes('application/json')) {
          try {
            data = await res.json();
          } catch (jsonErr) {
            console.warn('Failed to parse response JSON from server:', jsonErr);
          }
        } else {
          const rawText = await res.text();
          console.warn('Server returned non-JSON response status', res.status, rawText.slice(0, 150));
        }

        // Handle rate limiting / quota cooldown
        if (res.status === 429 || data?.isRateLimit) {
          const cooldown = data?.retryAfter || 28;
          setRateLimitCountdown(cooldown);
          setErrorMessage(
            data?.error || `Gemini Free Tier quota reached. Automatic retry scheduled in ${cooldown} seconds.`
          );
          break;
        }

        if (!res.ok || !data) {
          if (res.status === 504 || res.status === 502) {
            setErrorMessage('ဆာဗာ တုံ့ပြန်မှု နှေးကွေးနေပါသည် (Gateway Timeout). ကျေးဇူးပြု၍ ခေတ္တစောင့်ပြီး ထပ်မံကြိုးစားပါ။');
          } else {
            setErrorMessage(data?.error || `Translation request failed (HTTP ${res.status}). Please check your connection and try again.`);
          }
          break;
        }

        if (data.translations) {
          for (const item of data.translations) {
            const indexInArray = updatedBlocks.findIndex((b) => b.id === item.id);
            if (indexInArray !== -1) {
              updatedBlocks[indexInArray] = {
                ...updatedBlocks[indexInArray],
                burmeseText: item.burmeseText,
                notes: item.ambiguityNote,
                issues: item.issues,
                status: 'translated',
              };
            }
          }
        }

        if (data.detectedAmbiguities) {
          allAmbiguities.push(...data.detectedAmbiguities);
        }

        if (data.generalFeedback) {
          setFeedbackNote(data.generalFeedback);
        }

        // update UI progressively without losing any lines
        setBlocks([...updatedBlocks]);

        if (stopRequestedRef.current) {
          break;
        }

        // If there are more chunks, add a pause that can be cancelled immediately
        if (i + BATCH_SIZE < blocks.length) {
          for (let step = 0; step < 15; step++) {
            if (stopRequestedRef.current) break;
            await new Promise((resolve) => setTimeout(resolve, 100));
          }
          if (stopRequestedRef.current) break;
        }
      }

      // Mark translation as completed / revealed if any blocks were translated
      if (updatedBlocks.some((b) => b.burmeseText)) {
        setHasCompletedTranslation(true);
      }

      setDetectedAmbiguities(allAmbiguities);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Translation error:', err);
        const isFetchError = err?.message?.includes('Failed to fetch') || err?.name === 'TypeError';
        setErrorMessage(
          isFetchError
            ? 'ဆာဗာသို့ ချိတ်ဆက်မှု အဆင်မပြေပါ (Network / Server connection issue. Please click Translate again).'
            : err?.message || 'Translation error occurred.'
        );
      }
    } finally {
      setIsTranslating(false);
      abortControllerRef.current = null;
    }
  };

  // Resolve ambiguity choice
  const handleResolveAmbiguity = (blockId: number, selectedText: string) => {
    handleUpdateBlockText(blockId, selectedText);
    setDetectedAmbiguities((prev) =>
      prev.map((a) => (a.blockId === blockId ? { ...a, resolvedChoice: selectedText } : a))
    );
  };

  const handleDismissAmbiguity = (blockId: number) => {
    setDetectedAmbiguities((prev) => prev.filter((a) => a.blockId !== blockId));
  };

  // Clear all Burmese translations
  const handleClearTranslations = () => {
    if (confirm('Are you sure you want to clear all translated Burmese lines?')) {
      setBlocks((prev) => prev.map((b) => ({ ...b, burmeseText: '', status: 'pending', issues: [] })));
      setFeedbackNote(null);
      setDetectedAmbiguities([]);
      setRevealedBlockIds(new Set());
      setHasCompletedTranslation(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-rose-500/30 selection:text-rose-200">
      {/* Top Navbar */}
      <Navbar
        characterPolicy={settings.characterPolicy}
        onPolicyChange={(policy) => {
          setSettings((prev) => ({ ...prev, characterPolicy: policy }));
          setHasConfirmedPolicy(true);
        }}
        subtitleFormat={settings.subtitleFormat}
        onFormatChange={(fmt) => setSettings((prev) => ({ ...prev, subtitleFormat: fmt }))}
        modelProfile={settings.modelProfile}
        onModelProfileChange={(prof) => setSettings((prev) => ({ ...prev, modelProfile: prof }))}
        selectedModel={settings.selectedModel}
        onModelChange={(model) => setSettings((prev) => ({ ...prev, selectedModel: model, modelProfile: model }))}
        sourceLanguage={settings.sourceLanguage}
        onLanguageChange={(lang) => setSettings((prev) => ({ ...prev, sourceLanguage: lang }))}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenGuide={() => setIsGuideOpen(true)}
        onToggleChat={() => setIsChatOpen(!isChatOpen)}
        isChatOpen={isChatOpen}
        totalBlocks={blocks.length}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-8 space-y-6">
        {/* Workspace Toolbar: Samples, Upload, Actions */}
        <section className="bg-[#161b22] border border-[#30363d] rounded-2xl p-4 shadow-xl backdrop-blur-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Dynamic Genre & Context Adaptation (No Presets Required) */}
            <div className="w-full space-y-3">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/40 via-[#161b22] to-slate-900 border border-[#2ea043]/30 shadow-md">
                <div className="flex items-start sm:items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-[#2ea043]/15 text-[#3fb950] border border-[#2ea043]/30 shrink-0 shadow-sm shadow-[#2ea043]/10">
                    <Sparkles className="w-5 h-5 text-[#3fb950]" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        Dynamic Genre &amp; Context Adaptation Active
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#2ea043]/20 border border-[#2ea043]/40 text-[#3fb950] font-semibold">
                        No Presets Needed
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-950/60 border border-indigo-700/50 text-indigo-300 font-medium">
                        Universal 2-Speaker Split
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-950/60 border border-amber-700/50 text-amber-300 font-medium">
                        Auto Clean &amp; Filter
                      </span>
                    </div>
                    <p className="text-xs text-[#7d8590] mt-0.5 leading-relaxed">
                      ဇာတ်လမ်း၏ အကြောင်းအရာ၊ ဇာတ်ကောင်ဆက်ဆံရေးနှင့် စကားပြောဟန် (C Drama, Kdrama, Action, Comedy, Romance, Anime, etc.) ကို အလိုအလျောက် သုံးသပ်ပြီး သဘာဝကျသော ရုပ်ရှင်စကားပြောဟန်ဖြင့် ဘာသာပြန်ပေးပါသည်။
                    </p>
                  </div>
                </div>

                {/* Quick Context Dialogue Loader (For testing without fixed presets) */}
                <div className="flex items-center gap-2 shrink-0 pt-1 md:pt-0">
                  <span className="text-[11px] text-slate-400 font-medium hidden lg:inline">Test Dialogue:</span>
                  <select
                    value={activeSample || ''}
                    onChange={(e) => {
                      if (e.target.value) {
                        handleSelectSample(e.target.value as PresetKey);
                      }
                    }}
                    className="bg-[#21262d] border border-[#30363d] hover:border-[#2ea043] focus:border-[#2ea043] rounded-xl px-3 py-1.5 text-xs text-slate-200 font-medium focus:outline-none focus:ring-1 focus:ring-[#2ea043] cursor-pointer shadow-sm transition-all"
                    title="Load sample dialogues to test dynamic adaptation"
                  >
                    <option value="" disabled>Load Sample Context Dialogue...</option>
                    <option value="c_drama_srt">🏯 C Drama (Chinese Drama / Wuxia Split)</option>
                    <option value="kdrama_srt">🌸 Kdrama (Romance / Corporate Banter)</option>
                    <option value="anime_ass">⚔️ Anime .ASS (Tag Preservation &amp; Split)</option>
                    <option value="action_srt">💥 Action .SRT (Military / High-Stakes)</option>
                    <option value="comedy_srt">😂 Comedy .SRT (Colloquial Banter)</option>
                    <option value="romance_srt">💖 Romance .SRT (Intimate Spoken)</option>
                    <option value="horror_thriller_srt">🕯️ Horror / Thriller .SRT</option>
                    <option value="crime_mystery_srt">🔍 Crime / Mystery .SRT</option>
                    <option value="historical_period_srt">👑 Historical / Period .SRT</option>
                    <option value="animation_srt">🎨 Animation .SRT</option>
                    <option value="variety_show_srt">📺 Variety Show .SRT</option>
                    <option value="reality_show_srt">🏝️ Reality Show .SRT</option>
                  </select>
                </div>
              </div>
            </div>

            {/* View Mode Switcher */}
            <div className="flex items-center bg-[#0e1117] border border-[#30363d] rounded-xl p-1 text-xs">
              <button
                type="button"
                onClick={() => setViewMode('split')}
                className={`px-3 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                  viewMode === 'split'
                    ? 'bg-[#2ea043] text-white shadow-sm'
                    : 'text-[#7d8590] hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Split View</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('editor')}
                className={`px-3 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                  viewMode === 'editor'
                    ? 'bg-[#2ea043] text-white shadow-sm'
                    : 'text-[#7d8590] hover:text-white'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Editor Only</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('player')}
                className={`px-3 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                  viewMode === 'player'
                    ? 'bg-[#2ea043] text-white shadow-sm'
                    : 'text-[#7d8590] hover:text-white'
                }`}
              >
                <Tv className="w-3.5 h-3.5" />
                <span>Cinema Preview</span>
              </button>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-[#30363d]">
            {/* Import options */}
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#21262d] hover:bg-[#30363d] text-slate-200 hover:text-white cursor-pointer transition-colors text-xs font-medium border border-[#30363d]">
                <Upload className="w-3.5 h-3.5 text-[#3fb950]" />
                <span>Upload .SRT / .ASS</span>
                <input
                  type="file"
                  accept=".srt,.ass,.ssa,.txt"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              <button
                type="button"
                onClick={() => setRawPasteOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-[#21262d] hover:bg-[#30363d] text-slate-200 hover:text-white text-xs font-medium transition-colors border border-[#30363d] cursor-pointer"
              >
                Paste SRT / ASS
              </button>

              {blocks.some((b) => b.burmeseText) && (
                <button
                  type="button"
                  onClick={handleClearTranslations}
                  className="p-1.5 rounded-xl text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                  title="Clear translated Burmese text"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Translate & Export Actions */}
            <div className="flex items-center gap-2.5">
              {isTranslating ? (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#238636] text-white text-xs font-semibold opacity-95 shadow-sm cursor-wait"
                  >
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Translating ({translationProgress.current}/{translationProgress.total})...</span>
                  </button>

                  {/* Functional Real-Time Stop Translation Button */}
                  <button
                    type="button"
                    onClick={handleStopTranslation}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white text-xs font-bold shadow-lg shadow-rose-600/30 transition-all cursor-pointer animate-pulse"
                    title="Stop AI translation immediately without losing already translated lines"
                  >
                    <Square className="w-3.5 h-3.5 fill-current" />
                    <span>Stop Translation (ရပ်တန့်မည်)</span>
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleStartTranslate}
                  disabled={blocks.length === 0}
                  className="flex items-center gap-2 px-5 py-2 rounded-xl bg-[#2ea043] hover:bg-[#238636] disabled:opacity-50 text-white text-xs font-semibold shadow-lg shadow-[#2ea043]/20 transition-all cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Translate to Spoken Burmese</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setIsExportOpen(true)}
                disabled={blocks.length === 0}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#21262d] hover:bg-[#30363d] text-slate-200 hover:text-white text-xs font-semibold border border-[#30363d] transition-all cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-[#3fb950]" />
                <span>Export Subtitles</span>
              </button>
            </div>
          </div>

          {/* Translation Stopped Progress Saved Toast */}
          {translationStoppedNotice && (
            <div className="flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl bg-amber-950/40 border border-amber-600/50 text-xs text-amber-200 animate-in fade-in">
              <div className="flex items-center gap-2.5">
                <Square className="w-4 h-4 text-rose-400 fill-current shrink-0" />
                <span className="font-medium">{translationStoppedNotice}</span>
              </div>
              <button
                type="button"
                onClick={() => setTranslationStoppedNotice(null)}
                className="text-amber-400 hover:text-white text-xs font-semibold underline cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          )}


        </section>

        {/* Rate Limit Cooldown Alert */}
        {rateLimitCountdown !== null && rateLimitCountdown > 0 && (
          <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/50 text-amber-200 shadow-xl space-y-2 animate-in fade-in">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white">
                      Gemini API Rate Limit Cooldown Active
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {rateLimitCountdown}s remaining
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Free tier quota limit reached (5 requests/min). The system is resting and will automatically retry your translation in <span className="font-bold text-amber-300">{rateLimitCountdown}s</span>.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setRateLimitCountdown(null);
                    setErrorMessage(null);
                    handleStartTranslate();
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer"
                >
                  Retry Now
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setRateLimitCountdown(null);
                    setErrorMessage(null);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-[#21262d] hover:bg-[#30363d] text-slate-300 text-xs transition-colors cursor-pointer"
                >
                  Dismiss
                </button>
              </div>
            </div>

            {/* Visual Progress countdown bar */}
            <div className="w-full h-1 bg-amber-950/60 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-rose-500 transition-all duration-1000 ease-linear"
                style={{ width: `${Math.max(0, Math.min(100, (rateLimitCountdown / 30) * 100))}%` }}
              />
            </div>
          </div>
        )}

        {/* Generic Error Alert */}
        {errorMessage && rateLimitCountdown === null && (
          <div className="p-3.5 rounded-2xl bg-rose-950/30 border border-rose-900/60 text-rose-300 flex items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
              <p className="text-xs">{errorMessage}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleStartTranslate}
                className="px-3 py-1 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold cursor-pointer"
              >
                Retry
              </button>
              <button
                type="button"
                onClick={() => setErrorMessage(null)}
                className="text-xs text-slate-400 hover:text-white px-2 py-1 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}

        {/* Live Subtitle Quality & Rule Compliance Banner */}
        <RuleValidatorBanner
          blocks={blocks}
          totalIssues={validationStats.totalIssues}
          errorCount={validationStats.errorCount}
          warningCount={validationStats.warningCount}
          onAutoFixAll={handleAutoFixAll}
        />

        {/* AI Ambiguities & Clarification Section (if any detected) */}
        <AiClarificationPanel
          ambiguities={detectedAmbiguities}
          onResolve={handleResolveAmbiguity}
          onDismiss={handleDismissAmbiguity}
        />

        {/* Feedback / General Localization Notes */}
        {feedbackNote && (
          <div className="p-3.5 bg-[#161b22] border border-[#30363d] rounded-xl text-xs text-slate-300 flex items-start gap-2.5">
            <span className="text-[#3fb950] text-base leading-none">🎬</span>
            <div className="space-y-0.5">
              <span className="font-semibold text-white">Director's Localization Note:</span>
              <p className="text-[#7d8590] leading-relaxed">{feedbackNote}</p>
            </div>
          </div>
        )}

        {/* Main Work Area: Dual Split View or Dedicated Modes */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Subtitle List Editor Column */}
          <div
            className={`space-y-3 ${
              viewMode === 'editor'
                ? 'lg:col-span-12'
                : viewMode === 'player'
                ? 'hidden'
                : 'lg:col-span-7'
            }`}
          >
            {/* Header with Display Control Rule (Reveal All / Hide All) */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs px-1 text-[#7d8590]">
              <div className="flex items-center gap-2">
                <span className="font-semibold uppercase tracking-wider text-slate-300">
                  Subtitle Blocks ({blocks.length} lines)
                </span>
                <span className="text-[11px] text-[#7d8590]">
                  • 1:1 Line Mapping
                </span>
              </div>

              {/* Display Control Rule: Reveal / Hide toggles */}
              <div className="flex items-center gap-2">
                {hasCompletedTranslation ? (
                  <>
                    <button
                      type="button"
                      onClick={handleRevealAll}
                      className="px-2.5 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-[#3fb950] border border-[#30363d] text-[11px] font-medium transition-all cursor-pointer flex items-center gap-1"
                      title="Reveal all translated subtitle blocks"
                    >
                      <span>👀 အားလုံးဖွင့်ရန်</span>
                      <span className="text-[10px] bg-[#161b22] px-1.5 py-0.2 rounded text-[#3fb950]">
                        {blocks.filter((b) => b.burmeseText).length}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={handleHideAll}
                      className="px-2.5 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-[#7d8590] hover:text-white border border-[#30363d] text-[11px] font-medium transition-all cursor-pointer flex items-center gap-1"
                      title="Hide / collapse all translated blocks"
                    >
                      <span>🙈 အားလုံးဝှက်ရန်</span>
                    </button>
                  </>
                ) : (
                  <span className="text-[11px] text-[#7d8590] flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#21262d] border border-[#30363d]">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span>
                    <span>🔒 Output Hidden Until Translated</span>
                  </span>
                )}
              </div>
            </div>

            {/* Strict Display Control Banner: Hidden Until Translated */}
            {!hasCompletedTranslation ? (
              <div className="p-4 rounded-xl bg-[#161b22] border border-dashed border-[#30363d] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#2ea043]/15 border border-[#2ea043]/30 text-[#3fb950] flex items-center justify-center shrink-0">
                    <EyeOff className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-white block">
                      ဘာသာပြန်ရန် စောင့်ဆိုင်းနေပါသည်...
                    </span>
                    <span className="text-[#7d8590]">
                      Strict Display Control active: ဘာသာပြန်ပြီးမှ Output စာတန်းထိုးများကို ကြည့်ရှုခွင့် ရရှိပါမည် (Hidden Until Translated)
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleStartTranslate}
                  disabled={isTranslating || blocks.length === 0}
                  className="px-4 py-2 rounded-xl bg-[#2ea043] hover:bg-[#238636] disabled:opacity-50 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-[#2ea043]/20 transition-all cursor-pointer shrink-0"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Translate Now</span>
                </button>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-emerald-950/30 border border-[#2ea043]/40 flex flex-wrap items-center justify-between gap-2 text-xs animate-in fade-in">
                <div className="flex items-center gap-2">
                  <span className="text-[#3fb950] font-bold">✓ ဘာသာပြန်ခြင်း ပြီးစီးပါပြီ (Translation Completed)</span>
                  <span className="text-slate-400">• အောက်ပါ စာတန်းထိုး block များကို ဖွင့်ကြည့်နိုင်ပါပြီ</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleRevealAll}
                    className="text-[#3fb950] hover:underline text-[11px] font-medium cursor-pointer"
                  >
                    အားလုံးဖွင့်ရန် ({blocks.filter((b) => b.burmeseText).length})
                  </button>
                  <span className="text-slate-600">|</span>
                  <button
                    type="button"
                    onClick={handleHideAll}
                    className="text-slate-400 hover:text-white text-[11px] cursor-pointer"
                  >
                    အားလုံးဝှက်ရန်
                  </button>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {blocks.map((block, idx) => (
                <SubtitleBlockRow
                  key={block.id}
                  block={block}
                  index={idx}
                  isRevealed={revealedBlockIds.has(block.id)}
                  hasCompletedTranslation={hasCompletedTranslation}
                  onToggleReveal={handleToggleReveal}
                  onUpdateText={handleUpdateBlockText}
                  onJumpToTime={(ms) => setCurrentTimeMs(ms)}
                  genre={settings.genre}
                  pronouns={settings.pronouns}
                />
              ))}
            </div>
          </div>

          {/* Subtitle Cinema Video Player Column */}
          <div
            className={`sticky top-20 ${
              viewMode === 'player'
                ? 'lg:col-span-12'
                : viewMode === 'editor'
                ? 'hidden'
                : 'lg:col-span-5'
            }`}
          >
            <SubtitlePlayerPreview
              blocks={blocks}
              currentTimeMs={currentTimeMs}
              hasCompletedTranslation={hasCompletedTranslation}
              onTimeUpdate={(ms) => setCurrentTimeMs(ms)}
            />
          </div>
        </div>
      </main>

      {/* Raw Paste Modal */}
      {rawPasteOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white">Paste Raw .SRT Content</h3>
            <textarea
              rows={8}
              value={rawPasteText}
              onChange={(e) => setRawPasteText(e.target.value)}
              placeholder={`1\n00:00:01,000 --> 00:00:04,000\nHello, how are you today?`}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
            <div className="flex justify-end gap-2.5 text-xs">
              <button
                type="button"
                onClick={() => setRawPasteOpen(false)}
                className="px-4 py-2 text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApplyRawPaste}
                disabled={!rawPasteText.trim()}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold rounded-xl"
              >
                Load Subtitles
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modals & Drawers */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSave={(updated) => {
          setSettings(updated);
          setHasConfirmedPolicy(true);
        }}
      />

      <RulesGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        blocks={blocks}
        defaultFormat={settings.subtitleFormat}
        assHeaders={settings.assHeaders}
      />

      <PolicyPromptModal
        isOpen={isPolicyPromptOpen}
        onSelectPolicy={(policy) => {
          setSettings((prev) => ({ ...prev, characterPolicy: policy }));
          setHasConfirmedPolicy(true);
          setIsPolicyPromptOpen(false);
          // Auto start translation if user clicked translate
          handleStartTranslate();
        }}
        onCancel={() => setIsPolicyPromptOpen(false)}
      />

      <AiChatDrawer
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        blocks={blocks}
      />
    </div>
  );
}
