package com.mmchannel.subtitleeditor.util

import android.content.Context
import android.net.Uri
import com.mmchannel.subtitleeditor.model.SubtitleCue
import java.io.File
import java.io.FileOutputStream

enum class SubtitleFormat { SRT, VTT }

object SubtitleFileManager {

    fun formatFromFileName(name: String): SubtitleFormat =
        if (name.lowercase().endsWith(".vtt")) SubtitleFormat.VTT else SubtitleFormat.SRT

    fun importFrom(context: Context, uri: Uri): List<SubtitleCue> {
        val name = queryDisplayName(context, uri) ?: uri.lastPathSegment ?: "subtitle.srt"
        val format = formatFromFileName(name)
        context.contentResolver.openInputStream(uri).use { stream ->
            requireNotNull(stream) { "Could not open $uri" }
            return when (format) {
                SubtitleFormat.SRT -> SrtParser.parse(stream)
                SubtitleFormat.VTT -> VttParser.parse(stream)
            }
        }
    }

    /** Writes cues to a file inside the app's external files dir and returns it. */
    fun exportToFile(context: Context, cues: List<SubtitleCue>, format: SubtitleFormat, baseName: String): File {
        val dir = File(context.getExternalFilesDir(null), "MMChannel").apply { mkdirs() }
        val ext = if (format == SubtitleFormat.VTT) "vtt" else "srt"
        val outFile = File(dir, "$baseName.$ext")
        FileOutputStream(outFile).use { out ->
            when (format) {
                SubtitleFormat.SRT -> SrtParser.write(cues, out)
                SubtitleFormat.VTT -> VttParser.write(cues, out)
            }
        }
        return outFile
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex("_display_name")
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
