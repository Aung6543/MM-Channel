package com.mmchannel.subtitleeditor.ui

import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.mmchannel.subtitleeditor.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val pickVideoLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { openEditor(videoUri = it, subtitleUri = null) }
    }

    private val pickSubtitleLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { openEditor(videoUri = null, subtitleUri = it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonPickVideo.setOnClickListener {
            pickVideoLauncher.launch("video/*")
        }
        binding.buttonOpenExisting.setOnClickListener {
            pickSubtitleLauncher.launch("*/*")
        }
    }

    private fun openEditor(videoUri: Uri?, subtitleUri: Uri?) {
        val intent = EditorActivity.newIntent(this, videoUri, subtitleUri)
        startActivity(intent)
    }
}
