package com.mmchannel.subtitleeditor.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mmchannel.subtitleeditor.databinding.ItemSubtitleBinding
import com.mmchannel.subtitleeditor.model.SubtitleCue
import com.mmchannel.subtitleeditor.util.TimeCodeUtil

class SubtitleAdapter(
    private val cues: MutableList<SubtitleCue>,
    private val onCueChanged: (SubtitleCue) -> Unit,
    private val onCueClicked: (SubtitleCue) -> Unit,
    private val onDeleteClicked: (SubtitleCue) -> Unit
) : RecyclerView.Adapter<SubtitleAdapter.CueViewHolder>() {

    inner class CueViewHolder(val binding: ItemSubtitleBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CueViewHolder {
        val binding = ItemSubtitleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CueViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CueViewHolder, position: Int) {
        val cue = cues[position]
        val b = holder.binding

        b.textIndex.text = (position + 1).toString()
        b.editStart.setText(TimeCodeUtil.msToSrt(cue.startMs))
        b.editEnd.setText(TimeCodeUtil.msToSrt(cue.endMs))
        b.editText.setText(cue.text)

        b.root.setOnClickListener { onCueClicked(cue) }
        b.buttonDelete.setOnClickListener { onDeleteClicked(cue) }

        b.editStart.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                cue.startMs = TimeCodeUtil.toMs(b.editStart.text.toString())
                onCueChanged(cue)
            }
        }
        b.editEnd.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                cue.endMs = TimeCodeUtil.toMs(b.editEnd.text.toString())
                onCueChanged(cue)
            }
        }
        b.editText.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                cue.text = b.editText.text.toString()
                onCueChanged(cue)
            }
        }
    }

    override fun getItemCount(): Int = cues.size

    fun submitList(newCues: List<SubtitleCue>) {
        cues.clear()
        cues.addAll(newCues.sortedBy { it.startMs })
        notifyDataSetChanged()
    }
}
