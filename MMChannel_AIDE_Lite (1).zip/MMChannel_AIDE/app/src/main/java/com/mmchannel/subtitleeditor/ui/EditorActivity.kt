package com.mmchannel.subtitleeditor.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.mmchannel.subtitleeditor.adapter.SubtitleAdapter
import com.mmchannel.subtitleeditor.databinding.ActivityEditorBinding
import com.mmchannel.subtitleeditor.model.SubtitleCue
import com.mmchannel.subtitleeditor.util.SubtitleFileManager
import com.mmchannel.subtitleeditor.util.SubtitleFormat
import com.mmchannel.subtitleeditor.util.TimeCodeUtil

/**
 * Lite build for on-device compilation (e.g. AIDE): uses the built-in
 * android.widget.VideoView instead of ExoPlayer, and has no FFmpeg
 * hardcode step, so it only needs plain AndroidX libraries to build.
 */
class EditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditorBinding
    private var videoUri: Uri? = null

    private val cues = mutableListOf<SubtitleCue>()
    private lateinit var adapter: SubtitleAdapter

    private val importLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { importSubtitles(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        videoUri = intent.getParcelableExtra(EXTRA_VIDEO_URI)
        val subtitleUri: Uri? = intent.getParcelableExtra(EXTRA_SUBTITLE_URI)

        setupVideo()
        setupList()
        setupButtons()

        subtitleUri?.let { importSubtitles(it) }
    }

    private fun setupVideo() {
        videoUri?.let { uri ->
            binding.videoView.setVideoURI(uri)
            binding.videoView.setMediaController(MediaController(this).apply {
                setAnchorView(binding.videoView)
            })
            binding.videoView.setOnPreparedListener { it.isLooping = false }
        }

        binding.videoView.postDelayed(object : Runnable {
            override fun run() {
                val pos = try {
                    binding.videoView.currentPosition.toLong()
                } catch (e: Exception) {
                    0L
                }
                binding.textCurrentTime.text = TimeCodeUtil.msToSrt(pos)
                binding.videoView.postDelayed(this, 200)
            }
        }, 200)
    }

    private fun setupList() {
        adapter = SubtitleAdapter(
            cues = cues,
            onCueChanged = { /* edited in place */ },
            onCueClicked = { cue -> binding.videoView.seekTo(cue.startMs.toInt()) },
            onDeleteClicked = { cue ->
                cues.remove(cue)
                adapter.submitList(cues)
            }
        )
        binding.recyclerCues.layoutManager = LinearLayoutManager(this)
        binding.recyclerCues.adapter = adapter
    }

    private fun setupButtons() {
        binding.buttonAddCueHere.setOnClickListener {
            val start = try { binding.videoView.currentPosition.toLong() } catch (e: Exception) { 0L }
            val cue = SubtitleCue(index = cues.size + 1, startMs = start, endMs = start + 2000, text = "")
            cues.add(cue)
            adapter.submitList(cues)
        }

        binding.buttonImport.setOnClickListener { importLauncher.launch("*/*") }
        binding.buttonExportSrt.setOnClickListener { exportText(SubtitleFormat.SRT) }
        binding.buttonExportVtt.setOnClickListener { exportText(SubtitleFormat.VTT) }

        binding.buttonHardcode.setOnClickListener {
            Toast.makeText(
                this,
                "Hardcoding needs FFmpeg, which isn't in this lite build. Use the full build.gradle.kts version in Android Studio for this feature.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun importSubtitles(uri: Uri) {
        try {
            val imported = SubtitleFileManager.importFrom(this, uri)
            cues.clear()
            cues.addAll(imported)
            adapter.submitList(cues)
            Toast.makeText(this, "Imported ${imported.size} cues", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportText(format: SubtitleFormat) {
        if (cues.isEmpty()) {
            Toast.makeText(this, "No subtitle cues to export yet", Toast.LENGTH_SHORT).show()
            return
        }
        val file = SubtitleFileManager.exportToFile(this, cues, format, "mm_channel_subtitles")
        Toast.makeText(this, "Saved: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val EXTRA_VIDEO_URI = "extra_video_uri"
        private const val EXTRA_SUBTITLE_URI = "extra_subtitle_uri"

        fun newIntent(context: Context, videoUri: Uri?, subtitleUri: Uri?): Intent {
            return Intent(context, EditorActivity::class.java).apply {
                putExtra(EXTRA_VIDEO_URI, videoUri)
                putExtra(EXTRA_SUBTITLE_URI, subtitleUri)
            }
        }
    }
}
