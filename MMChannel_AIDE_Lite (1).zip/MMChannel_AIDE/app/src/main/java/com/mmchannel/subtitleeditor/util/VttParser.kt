package com.mmchannel.subtitleeditor.util

import com.mmchannel.subtitleeditor.model.SubtitleCue
import java.io.InputStream
import java.io.OutputStream

/**
 * Reads and writes WebVTT (.vtt) subtitle files:
 *
 * WEBVTT
 * (blank line)
 * 00:00:01.000 --> 00:00:04.000
 * Hello world
 */
object VttParser {

    private val TIME_LINE = Regex(
        """(\d{1,2}:\d{2}:\d{2}[.,]\d{1,3}|\d{2}:\d{2}[.,]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[.,]\d{1,3}|\d{2}:\d{2}[.,]\d{1,3})"""
    )

    fun parse(input: InputStream): List<SubtitleCue> {
        return parse(input.bufferedReader(Charsets.UTF_8).readText())
    }

    fun parse(text: String): List<SubtitleCue> {
        val cues = mutableListOf<SubtitleCue>()
        val body = text.replace("\r\n", "\n").replace("\r", "\n")
        val blocks = body.split(Regex("\n\\s*\n"))

        var autoIndex = 1
        for (block in blocks) {
            val lines = block.trim().lines().filter { it.isNotBlank() && !it.startsWith("WEBVTT") }
            if (lines.isEmpty()) continue

            val timeLineIndex = lines.indexOfFirst { TIME_LINE.containsMatchIn(it) }
            if (timeLineIndex == -1) continue

            val match = TIME_LINE.find(lines[timeLineIndex]) ?: continue
            val start = TimeCodeUtil.toMs(match.groupValues[1])
            val end = TimeCodeUtil.toMs(match.groupValues[2])
            val cueText = lines.subList(timeLineIndex + 1, lines.size).joinToString("\n").trim()

            cues.add(SubtitleCue(index = autoIndex, startMs = start, endMs = end, text = cueText))
            autoIndex++
        }
        return cues
    }

    fun write(cues: List<SubtitleCue>, output: OutputStream) {
        val writer = output.bufferedWriter(Charsets.UTF_8)
        writer.write("WEBVTT")
        writer.newLine()
        writer.newLine()
        cues.sortedBy { it.startMs }.forEach { cue ->
            writer.write("${TimeCodeUtil.msToVtt(cue.startMs)} --> ${TimeCodeUtil.msToVtt(cue.endMs)}")
            writer.newLine()
            writer.write(cue.text)
            writer.newLine()
            writer.newLine()
        }
        writer.flush()
    }

    fun toVttString(cues: List<SubtitleCue>): String {
        val sb = StringBuilder("WEBVTT\n\n")
        cues.sortedBy { it.startMs }.forEach { cue ->
            sb.append(TimeCodeUtil.msToVtt(cue.startMs)).append(" --> ").append(TimeCodeUtil.msToVtt(cue.endMs)).append('\n')
            sb.append(cue.text).append('\n').append('\n')
        }
        return sb.toString()
    }
}
