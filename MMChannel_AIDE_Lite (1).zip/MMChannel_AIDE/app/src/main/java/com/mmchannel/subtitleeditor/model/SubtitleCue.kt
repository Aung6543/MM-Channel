package com.mmchannel.subtitleeditor.model

/**
 * A single subtitle line/cue.
 * startMs / endMs are in milliseconds from the start of the video.
 */
data class SubtitleCue(
    var index: Int,
    var startMs: Long,
    var endMs: Long,
    var text: String
) {
    val durationMs: Long get() = endMs - startMs

    fun overlaps(other: SubtitleCue): Boolean =
        startMs < other.endMs && endMs > other.startMs
}
