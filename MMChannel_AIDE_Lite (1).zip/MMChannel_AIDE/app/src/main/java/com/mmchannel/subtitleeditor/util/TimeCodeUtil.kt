package com.mmchannel.subtitleeditor.util

import java.util.Locale

/**
 * Converts between millisecond timestamps and the text formats used by
 * SRT ("00:00:01,000") and WebVTT ("00:00:01.000").
 */
object TimeCodeUtil {

    fun msToSrt(ms: Long): String {
        val (h, m, s, milli) = split(ms)
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, milli)
    }

    fun msToVtt(ms: Long): String {
        val (h, m, s, milli) = split(ms)
        return String.format(Locale.US, "%02d:%02d:%02d.%03d", h, m, s, milli)
    }

    /** Accepts both comma (SRT) and dot (VTT) millisecond separators. */
    fun toMs(timeCode: String): Long {
        val cleaned = timeCode.trim().replace(',', '.')
        val parts = cleaned.split(":")
        return try {
            val h: Long
            val m: Long
            val secPart: String
            when (parts.size) {
                3 -> {
                    h = parts[0].toLong()
                    m = parts[1].toLong()
                    secPart = parts[2]
                }
                2 -> {
                    h = 0
                    m = parts[0].toLong()
                    secPart = parts[1]
                }
                else -> return 0L
            }
            val secSplit = secPart.split(".")
            val s = secSplit[0].toLong()
            val milli = if (secSplit.size > 1) secSplit[1].padEnd(3, '0').take(3).toLong() else 0L
            (h * 3600 + m * 60 + s) * 1000 + milli
        } catch (e: NumberFormatException) {
            0L
        }
    }

    private data class Split(val h: Long, val m: Long, val s: Long, val milli: Long)

    private fun split(ms: Long): Split {
        var remaining = ms
        if (remaining < 0) remaining = 0
        val milli = remaining % 1000
        remaining /= 1000
        val s = remaining % 60
        remaining /= 60
        val m = remaining % 60
        remaining /= 60
        val h = remaining
        return Split(h, m, s, milli)
    }
}
