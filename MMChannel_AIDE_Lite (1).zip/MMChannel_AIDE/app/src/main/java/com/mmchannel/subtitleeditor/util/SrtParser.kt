package com.mmchannel.subtitleeditor.util

import com.mmchannel.subtitleeditor.model.SubtitleCue
import java.io.InputStream
import java.io.OutputStream

/**
 * Reads and writes the SubRip (.srt) subtitle format:
 *
 * 1
 * 00:00:01,000 --> 00:00:04,000
 * Hello world
 * (blank line)
 */
object SrtParser {

    private val TIME_LINE = Regex(
        """(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})"""
    )

    fun parse(input: InputStream): List<SubtitleCue> {
        val text = input.bufferedReader(Charsets.UTF_8).readText()
        return parse(text)
    }

    fun parse(text: String): List<SubtitleCue> {
        val cues = mutableListOf<SubtitleCue>()
        // Normalize line endings and split into blocks separated by blank lines.
        val blocks = text.replace("\r\n", "\n").replace("\r", "\n").split(Regex("\n\\s*\n"))

        var autoIndex = 1
        for (block in blocks) {
            val lines = block.trim().lines().filter { it.isNotBlank() }
            if (lines.isEmpty()) continue

            // First line may be a numeric index; if so skip it, otherwise treat as text.
            var lineIdx = 0
            if (lines[0].trim().toIntOrNull() != null && lines.size > 1 && TIME_LINE.containsMatchIn(lines[1])) {
                lineIdx = 1
            }

            val timeLineIndex = lines.indexOfFirst { TIME_LINE.containsMatchIn(it) }
            if (timeLineIndex == -1) continue

            val match = TIME_LINE.find(lines[timeLineIndex]) ?: continue
            val start = TimeCodeUtil.toMs(match.groupValues[1])
            val end = TimeCodeUtil.toMs(match.groupValues[2])
            val textLines = lines.subList(timeLineIndex + 1, lines.size)
            val cueText = textLines.joinToString("\n").trim()

            cues.add(SubtitleCue(index = autoIndex, startMs = start, endMs = end, text = cueText))
            autoIndex++
            lineIdx = lineIdx // no-op, keeps intent clear
        }
        return cues
    }

    fun write(cues: List<SubtitleCue>, output: OutputStream) {
        val writer = output.bufferedWriter(Charsets.UTF_8)
        cues.sortedBy { it.startMs }.forEachIndexed { i, cue ->
            writer.write((i + 1).toString())
            writer.newLine()
            writer.write("${TimeCodeUtil.msToSrt(cue.startMs)} --> ${TimeCodeUtil.msToSrt(cue.endMs)}")
            writer.newLine()
            writer.write(cue.text)
            writer.newLine()
            writer.newLine()
        }
        writer.flush()
    }

    fun toSrtString(cues: List<SubtitleCue>): String {
        val sb = StringBuilder()
        cues.sortedBy { it.startMs }.forEachIndexed { i, cue ->
            sb.append(i + 1).append('\n')
            sb.append(TimeCodeUtil.msToSrt(cue.startMs)).append(" --> ").append(TimeCodeUtil.msToSrt(cue.endMs)).append('\n')
            sb.append(cue.text).append('\n').append('\n')
        }
        return sb.toString()
    }
}
