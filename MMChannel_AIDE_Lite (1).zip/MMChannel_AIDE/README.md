# MM Channel — Subtitle Editor (AIDE-friendly Lite Build)

This is a trimmed-down version of the MM Channel subtitle editor, made to
build on-device in **AIDE** (Android IDE app), where large native/media
dependencies often fail to resolve or link.

## What's different from the full version

| Feature | Full version (Android Studio) | This lite version (AIDE) |
|---|---|---|
| Video preview | ExoPlayer (androidx.media3) | Built-in `VideoView` (no extra library) |
| Subtitle burn-in ("hardcode") | FFmpeg (`ffmpeg-kit-full`) | **Not included** — button shows an explanation instead |
| Import/export SRT & VTT | Yes | Yes, same, pure Kotlin |
| Timing/text editing per cue | Yes | Yes, same |

Only `androidx.core`, `androidx.appcompat`, `material`, `constraintlayout`,
`recyclerview`, and `activity-ktx` are needed — all small, well-mirrored
libraries AIDE's on-device Gradle can usually fetch.

## How to open this in AIDE

1. Install **AIDE** from the Play Store (or F-Droid build if you prefer).
2. Unzip this project somewhere AIDE can see, e.g.
   `/storage/emulated/0/AIDEProjects/MMChannel/`.
3. In AIDE: Open Project, point it at the folder containing
   `settings.gradle.kts`.
4. Let it sync/download dependencies (needs internet the first time).
5. Run from within AIDE, or use AIDE's Build APK action.

## If AIDE still struggles

Even this lighter dependency set can be slow or occasionally fail on
older/low-RAM phones, because AIDE's Gradle integration is less robust
than desktop Android Studio. If it still won't build:

- Try building with only Wi-Fi, since dependency downloads can be large.
- Give it multiple attempts — first sync often partially fails, retries
  usually complete since already-downloaded artifacts are cached.
- As a fallback with zero local build tooling at all, push this folder to
  a GitHub repo and let GitHub Actions build the APK in the cloud —
  ask if you'd like that workflow file set up.

## Getting the hardcode (burn-in) feature back

That needs FFmpeg, which is impractical to compile on-device. Once you
have a working APK from this lite build, if you later get access to a
PC, open the full version (with `ffmpeg-kit-full` in
`app/build.gradle.kts` and `export/HardcodeExporter.kt`) in Android
Studio to add that feature back in.

## Building via GitHub Actions (recommended — no on-device build needed)

This project includes `.github/workflows/android-build.yml`, which builds
a debug APK on GitHub's own servers every time you push code. You only
need a phone browser and a free GitHub account — no Gradle wrapper,
Android Studio, or AIDE build step required.

### Steps (all doable from your phone browser)

1. Go to github.com, log in, and create a **new repository** (e.g.
   `mm-channel`). Keep it either public or private — both work.
2. Open the new repo, tap **Add file → Upload files**.
3. Upload every file/folder from this project, preserving the folder
   structure (`app/`, `.github/`, `settings.gradle.kts`, etc.) — GitHub's
   web uploader supports dragging a whole folder or a zip's extracted
   contents.
4. Commit the upload (the commit itself triggers the workflow).
5. Tap the **Actions** tab at the top of the repo. You should see a
   run of "Build MM Channel APK" in progress (a few minutes).
6. Once it finishes with a green check, open that run and scroll to
   **Artifacts** at the bottom — download `MM-Channel-debug-apk`. That's
   a zip containing the installable `.apk`.
7. On your phone, extract that zip and tap the `.apk` to install
   (you may need to allow "install unknown apps" for your browser/files
   app the first time).

### If the Actions tab shows a failed run

Open the run, click the failed step, and read the red error text — it's
usually a missing/renamed dependency. Paste that error back for help
fixing it; cloud build logs are much easier to diagnose than on-device
AIDE output.
